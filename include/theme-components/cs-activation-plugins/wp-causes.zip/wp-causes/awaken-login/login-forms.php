<?php
/**
 * File Type : Login Form Html
 * @copyright Copyright (c) 2014, Chimp Studio 
 */
	
//=====================================================================
// Sign In With Social Media
//=====================================================================
if (!function_exists('cs_social_login_form')) {
	function cs_social_login_form( $args = NULL ) {
		global $cs_theme_options;
		$display_label = false;
		$plugin_url = plugin_dir_url( __FILE__ );
		if(get_option('users_can_register')) {
		if( $args == NULL )
			$display_label = true;
		elseif ( is_array( $args ) )
			extract( $args );
			
		//echo plugin_url();
		
		if( !isset( $images_url ) )
			$images_url = $plugin_url . 'cs-social-login/media/img/';
		$facebook_app_id = '';
		$facebook_secret = '';
		if(isset($cs_theme_options['cs_dashboard'])){
			$cs_dashboard_link = get_permalink($cs_theme_options['cs_dashboard']);
		}
		$twitter_enabled = $cs_theme_options['cs_twitter_api_switch'];
		$facebook_enabled = $cs_theme_options['cs_facebook_login_switch'];
		if(isset($cs_theme_options['cs_facebook_app_id']))
			$facebook_app_id = $cs_theme_options['cs_facebook_app_id'];
		if(isset($cs_theme_options['cs_facebook_secret']))
			$facebook_secret = $cs_theme_options['cs_facebook_secret'];
		$google_enabled = $cs_theme_options['cs_google_login_switch'];
		if(isset($cs_theme_options['cs_consumer_key']))
			$twitter_app_id = $cs_theme_options['cs_consumer_key'];
		if(isset($cs_theme_options['cs_google_client_id']))
			$google_app_id = $cs_theme_options['cs_google_client_id'];
		if ($twitter_enabled || $facebook_enabled || $google_enabled) :
		$rand_id = cs_generate_random_string(5);
		$isRegistrationOn = get_option('users_can_register');
		   if ( $isRegistrationOn ) {
		  		//cs_social_connect();   
		  ?>
            <div class="footer-element comment-form-social-connect social_login_ui <?php if( strpos( $_SERVER['REQUEST_URI'], 'wp-signup.php' ) ) echo 'mu_signup'; ?>">
                <h6><?php _e('Sign in with Social Account','Cause');?></h6>
              <div class="social_login_facebook_auth">
                <input type="hidden" name="client_id" value="<?php echo esc_attr($facebook_app_id); ?>" />
                <input type="hidden" name="redirect_uri" value="<?php echo home_url('index.php?social-login=facebook-callback'); ?>" />
              </div>
              <div class="social_login_twitter_auth">
                <input type="hidden" name="client_id" value="<?php echo esc_attr($twitter_app_id); ?>" />
                <input type="hidden" name="redirect_uri" value="<?php echo home_url('index.php?social-login=twitter'); ?>" />
              </div>
              <div class="social_login_google_auth">
                <input type="hidden" name="client_id" value="<?php echo esc_attr($google_app_id); ?>" />
                <input type="hidden" name="redirect_uri" value="<?php  echo cs_google_login_url() . (isset($_GET['redirect_to']) ? '&redirect=' . $_GET['redirect_to'] : '');?>" />
              </div>
              <p class="social-media social_login_form">	 
              <?php if( $facebook_enabled ) :
                        echo apply_filters('social_login_login_facebook','<a href="javascript:void(0);" title="Facebook" id="cs-social-login-'.$rand_id.'fb"  data-original-title="Facebook" class="social_login_login_facebook"><span class="social-mess-top fb-social-login" style="display:none">Please set API key</span><i class="fa fa-facebook"></i>'.__('Login With Facebook','Cause').'</a>');
                    endif; 
                    if( $twitter_enabled ) :
                        echo apply_filters('social_login_login_twitter','<a href="javascript:void(0);" title="Twitter" id="cs-social-login-'.$rand_id.'tw" data-original-title="twitter" class="social_login_login_twitter"><span class="social-mess-top tw-social-login" style="display:none">Please set API key</span><i class="fa fa-twitter"></i>'.__('Login With twitter','Cause').'</a>');
                    endif; 
                    if( $google_enabled ) :
                        echo apply_filters('social_login_login_google','<a  href="javascript:void(0);" rel="nofollow" title="google-plus" id="cs-social-login-'.$rand_id.'gp" data-original-title="google-plus" class="social_login_login_google"><span class="social-mess-top gplus-social-login" style="display:none">Please set API key</span><i class="fa fa-google-plus"></i>'.__('Login with Google Plus','Cause').'</a>');
                    endif; 
                $social_login_provider = isset( $_COOKIE['social_login_current_provider']) ? $_COOKIE['social_login_current_provider'] : '';
                do_action ('social_login_auth'); ?>  
              </p>
            </div>
    	<?php }?>
	<!-- End of social_login_ui div -->
	<?php endif;
		}
	}
}
add_action( 'login_form',          'cs_social_login_form', 10 );
add_action( 'social_form',          'cs_social_login_form', 10 );
add_action( 'after_signup_form',   'cs_social_login_form', 10 );
add_action( 'social_login_form', 'cs_social_login_form', 10 );


//=====================================================================
// General Sign In Section ( Form )
//=====================================================================
if ( ! function_exists( 'cs_login_section' ) ) {
	function cs_login_section($login='', $logout=''){
		global $current_user,$cs_theme_options;
		$rand_id = rand(5,999999);
		?>
		<section id="cs-signup" class="<?php if ( is_user_logged_in() ) { echo 'has-login cs-signup';} else {echo 'cs-signup';}?>"> 
              <!-- Header Element -->
              <?php  
                if ( is_user_logged_in() ) { 
                 $qrystr= "";
                 if(isset($cs_theme_options['cs_dashboard'])){
                    $cs_page_id = $cs_theme_options['cs_dashboard'];
                 }
                 $uid= $current_user->ID;
                $uid = get_current_user_id();
                $action = (isset($_GET['action']) && $_GET['action'] <> '') ? $_GET['action'] : $action	= '';
                if ( function_exists( 'cs_profile_menu' ) ) {
                    cs_profile_menu( $action ,$uid);
                }
              }else{
                ?>
                 <div class="modal fade model-wishlist " id="aweken_login" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-body">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"><i class="fa fa-times-circle"></i></span><span class="sr-only">Close</span></button>
                          <div class="main-signup">
                                  <div class="cs-login-form-section"> 
                                    <script>
                                        jQuery(document).ready(function(){
                                        jQuery("#cs-signup-form-section").hide();
                                        jQuery("#accout-already").hide();
                                          jQuery("#signup-now").click(function(){
                                            jQuery("#login-from-<?php echo esc_js($rand_id);?>").hide();
                                            jQuery("#signup-now").hide();
                                            jQuery("#cs-signup-form-section").show();
                                            jQuery("#accout-already").show();
                                          });
										  
                                          jQuery("#accout-already").click(function(){
                                            jQuery("#login-from-<?php echo esc_js($rand_id);?>").show();
                                            jQuery("#signup-now").show();
                                            jQuery("#cs-signup-form-section").hide();
                                            jQuery("#accout-already").hide();
                                          });
                                        });
                                     </script>
                                    <div class="header-element login-from login-form-id-<?php echo absint($rand_id);?>" id="login-from-<?php echo absint($rand_id);?>">
                                      <h6>
                                        <?php _e('Sign In','Cause');?>
                                      </h6>
                                      <form method="post" class="wp-user-form webkit" id="ControlForm_<?php echo absint($rand_id);?>">
                                        <fieldset>
                                          <p> 
                                            <span class="input-icon"><i class="fa fa-user"></i>
                                            <input type="text" name="user_login" size="20"  tabindex="11" onfocus="if(this.value =='Username') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Username'; }" value="Username" />
                                            </span> 
                                          </p>
                                          <p> 
                                            <span class="input-icon"><i class="fa fa-unlock-alt"></i>
                                            <input type="password" name="user_pass" size="20" tabindex="12" onfocus="if(this.value =='Password') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Password'; }" value="Password" />
                                            </span> 
                                          </p>
                                          <p>
                                            <input name="rememberme" value="forever" type="checkbox">
                                            <span class="remember-me">
                                            <?php _e('Remember me','Cause'); ?>
                                            </span> <span class="status status-message" style="display:none"></span> 
                                          </p>
                                          <p>
                                            <input type="button" name="user-submit" class="user-submit backcolr" value="<?php _e('login','Cause'); ?>" onclick="javascript:cs_user_authentication('<?php echo admin_url('admin-ajax.php')?>','<?php echo absint($rand_id);?>')" />
                                            <input type="hidden" name="redirect_to" value="<?php the_permalink(); ?>" />
                                            <input type="hidden" name="user-cookie" value="1" />
                                            <input type="hidden" value="ajax_login" name="action">
                                            <input type="hidden" name="login" value="login" />
                                          </p>
                                          <p><a href="<?php echo wp_lostpassword_url(); ?>">
                                            <?php _e('Forget Password?','Cause');?>
                                            </a>
                                          </p>
                                        </fieldset>
                                      </form>
                                    </div>
                                    <?php  $isRegistrationOn = get_option('users_can_register');
                                           if ( $isRegistrationOn ) {?>
                                             <div class="header-element cs-signup-form-section" id="cs-signup-form-section">
                                        <div class="cs-user-register">
                                          <h6><?php _e('Sign Up','Cause');?></h6>
                                          <form method="post" class="wp-user-form" id="wp_signup_form_<?php echo absint($rand_id);?>" enctype="multipart/form-data">
                                            <ul class="upload-file">
                                              <li>
                                              <i class="fa fa-user"></i>
                                                <input type="text" name="user_login" value="Username" onfocus="if(this.value =='Username') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Username'; }"  size="20" tabindex="101" />
                                              </li>
                                              <li>
                                              <i class="fa fa-envelope"></i>
                                                <input type="text" name="user_email" value="Email" onfocus="if(this.value =='Email') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Email'; }"  size="25" id="user_email" tabindex="101" />
                                              </li>
                                            </ul>
                                            <ul class="upload-file">
                                              <li>
                                                <?php echo do_action('register_form');?>
                                                <input type="button" name="user-submit"  value="<?php _e('Register Now','Cause');?>" class="user-submit backcolr"  onclick="javascript:cs_registration_validation('<?php echo admin_url("admin-ajax.php");?>','<?php echo absint($rand_id);?>')" />
                                                <div id="result_<?php echo absint($rand_id);?>" class="status-message"><p class="status"></p></div>
                                                <input type="hidden" name="role" value="member" />
                                                <input type="hidden" name="action" value="cs_registration_validation" />
                                              </li>
                                            </ul>
                                          </form>
                                        </div>
                                    </div>
                                    <?php }?>
                                </div>
                             <?php  $isRegistrationOn = get_option('users_can_register');
                                   if ( $isRegistrationOn ) {?>
                                        <?php do_action('login_form'); ?>
                                        <h6 id="signup-now" class="forget-link">Not a Member ? <a href="#" style="font-size:12px;"><?php _e('Signup Now','Cause');?></a></h6>
                                        <h6 id="accout-already" class="login-link">Already have an account? <a href="#" style="font-size:12px;"><?php _e('Login','Cause');?> </a></h6>
                                   <?php }?>
                                   </div>
                                    </div>
                      </div>
                   </div>
          
 </div>
           <?php } ?>
          <!-- Footer Element --> 
      </section>
  
 <?php
	}
}


//=====================================================================
// General Sign In Section ( Add to Wishlist Form )
//=====================================================================
if ( ! function_exists( 'cs_userlogin' ) ) {
	function cs_userlogin(){
		global $cs_theme_options;
		$rand_id	 = rand(5,999999);
		$isRegistrationOn = get_option('users_can_register');
		$isRegistrationOnClass	= '';
		if ( !$isRegistrationOn ) {
			$isRegistrationOnClass	= 'no_icon';
		}
		?>
		<!-- Modal -->
        <div class="modal fade model-wishlist <?php echo esc_attr($isRegistrationOnClass); ?>" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-body">
                <section class="cs-signup" style="display:block;">
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                     <div class="header-element login-from login-form-id-<?php echo absint($rand_id);?>" id="login-from-<?php echo absint($rand_id);?>">
                      <h6>
                        <?php _e('Sign in','Cause');?>
                      </h6>
                      <form method="post" class="wp-user-form webkit" id="ControlForm_<?php echo absint($rand_id);?>">
                        <fieldset>
                          <p> <span class="input-icon"><i class="fa fa-user"></i>
                            <input type="text" name="user_login" size="20" tabindex="11" onfocus="if(this.value =='Username') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Username'; }" value="Username" />
                            </span> 
                          </p>
                          <p> 
                            <span class="input-icon"><i class="fa fa-unlock-alt"></i>
                            <input type="password" name="user_pass" size="20" tabindex="12" onfocus="if(this.value =='Password') { this.value = ''; }" onblur="if(this.value == '') { this.value ='Password'; }" value="Password" />
                            </span> 
                          </p>
                          <p>
                            <input name="rememberme" value="forever" type="checkbox">
                            <span class="remember-me">
                            <?php _e('Remember me','Cause'); ?>
                            </span> <span class="status status-message" style="display:none"></span> </p>
                          <p>
                            <input type="button" name="user-submit" class="user-submit backcolr"  value="<?php _e('login','Cause'); ?>" onclick="javascript:cs_user_authentication('<?php echo admin_url('admin-ajax.php')?>','<?php echo absint($rand_id);?>')" />
                            <input type="hidden" name="redirect_to" value="<?php the_permalink(); ?>" />
                            <input type="hidden" name="user-cookie" value="1" />
                            <input type="hidden" value="ajax_login" name="action">
                            <input type="hidden" name="login" value="login" />
                          </p>
                          <p><a href="<?php echo wp_lostpassword_url( ); ?>">
                            <?php _e('Forget Password?','Cause');?>
                            </a>
                          </p>
                        </fieldset>
                      </form>
                    </div>
                  <?php do_action('login_form'); ?>
                </section>
              </div>
            </div>
          </div>
        </div>
	<?php
	}
}

//======================================================================
// Register html form for page builder start
//======================================================================
if ( ! function_exists( 'cs_pb_register' ) ) {
	function cs_pb_register($die = 0){
		global $cs_node, $count_node, $post;
		
		$shortcode_element = '';
		$filter_element = 'filterdrag';
		$shortcode_view = '';
		$output = array();
		$cs_counter = $_POST['counter'];
		$PREFIX = 'cs_register';
		$parseObject 	= new ShortcodeParse();
		$accordion_num = 0;
		if ( isset($_POST['action']) && !isset($_POST['shortcode_element_id']) ) {
			$POSTID = '';
			$shortcode_element_id = '';
		} else {
			$POSTID = $_POST['POSTID'];
			$shortcode_element_id = $_POST['shortcode_element_id'];
			$shortcode_str = stripslashes ($shortcode_element_id);
			$output = $parseObject->cs_shortcodes( $output, $shortcode_str , true , $PREFIX );
		}
		
		$defaults = array('column_size'=>'1/1','register_title'=>'','register_text'=>'','register_role' => 'contributor','cs_register_class'=>'','cs_register_animation'=>'');
		
		if(isset($output['0']['atts']))
			$atts = $output['0']['atts'];
		else 
			$atts = array();
		
		if(isset($output['0']['content']))
			$atts_content = $output['0']['content'];
		else 
			$atts_content = array();
		
		if(is_array($atts_content))
			$register_num = count($atts_content);
			
		$register_element_size = '100';
		foreach($defaults as $key=>$values){
			if(isset($atts[$key]))
				$$key = $atts[$key];
			else 
				$$key =$values;
		 }
		$name = 'cs_pb_register';
		$coloumn_class = 'column_'.$register_element_size;
		
		if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){
			$shortcode_element = 'shortcode_element_class';
			$shortcode_view = 'cs-pbwp-shortcode';
			$filter_element = 'ajax-drag';
			$coloumn_class = '';
		}
	?>
<div id="<?php echo esc_attr($name.$cs_counter)?>_del" class="column  parentdelete <?php echo esc_attr($coloumn_class);?> <?php echo esc_attr($shortcode_view);?>" item="blog" data="<?php echo element_size_data_array_index($register_element_size)?>" >
  <?php cs_element_setting($name,$cs_counter,$register_element_size,'','external-link');?>
  <div class="cs-wrapp-class-<?php echo esc_attr($cs_counter)?> <?php echo esc_attr($shortcode_element);?>" id="<?php echo esc_attr($name.$cs_counter)?>" data-shortcode-template="[cs_register {{attributes}}] {{content}} [/cs_register]" style="display: none;">
    <div class="cs-heading-area">
      <h5>Edit Register Form Options</h5>
      <a href="javascript:removeoverlay('<?php echo esc_attr($name.$cs_counter)?>','<?php echo esc_attr($filter_element);?>')" class="cs-btnclose"><i class="fa fa-times"></i></a> </div>
      <div class="cs-pbwp-content">
      <div class="cs-wrapp-clone cs-shortcode-wrapp cs-pbwp-content">
        <ul class="form-elements">
          <li class="to-label">
            <label>Form Title</label>
          </li>
          <li class="to-field">
            <input type="text" name="register_title[]" class="txtfield" value="<?php echo cs_allow_special_char($register_title)?>" />
          </li>
        </ul>
        
        <ul class="form-elements">
          <li class="to-label">
            <label>User Role</label>
          </li>
          <li class="to-field select-style">
            <select class="dropdown" name="register_role[]">
                <option value="">Select User Role</option>
                <option <?php if($register_role == 'subscriber') echo 'selected="selected"'; ?> value="subscriber">Subscriber</option>
                <option <?php if($register_role == 'staff') echo 'selected="selected"'; ?> value="staff">Staff</option>
                <option <?php if($register_role == 'member') echo 'selected="selected"'; ?> value="member">Member</option>
                <option <?php if($register_role == 'instructor') echo 'selected="selected"'; ?> value="instructor">Instructor</option>
                <option <?php if($register_role == 'shop_manager') echo 'selected="selected"'; ?> value="shop_manager">Shop Manager</option>
                <option <?php if($register_role == 'customer') echo 'selected="selected"'; ?> value="customer">Customer</option>
                <option <?php if($register_role == 'contributor') echo 'selected="selected"'; ?> value="contributor">Contributor</option>
                <option <?php if($register_role == 'author') echo 'selected="selected"'; ?> value="author">Author</option>
                <option <?php if($register_role == 'editor') echo 'selected="selected"'; ?> value="editor">Editor</option>
                <option <?php if($register_role == 'administrator') echo 'selected="selected"'; ?> value="administrator">Administrator</option>
            </select>
          </li>
        </ul>
        
        <ul class="form-elements">
          <li class="to-label">
            <label>Content</label>
          </li>
          <li class="to-field">
            <textarea class='txtfield' data-content-text="cs-shortcode-textarea" name="register_text[]"><?php echo esc_textarea($register_text)?></textarea>
          </li>
        </ul>
        
        <?php 
		if ( function_exists( 'cs_shortcode_custom_dynamic_classes' ) ) {
			cs_shortcode_custom_dynamic_classes($cs_register_class,$cs_register_animation,'','cs_register');
		}
		?>
      </div>
      <?php if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){?>
      <ul class="form-elements insert-bg">
        <li class="to-field"> <a class="insert-btn cs-main-btn" onclick="javascript:Shortcode_tab_insert_editor('<?php echo esc_js(str_replace('cs_pb_','',$name));?>','<?php echo esc_js($name.$cs_counter);?>','<?php echo esc_js($filter_element);?>')" >Insert</a> </li>
      </ul>
      <div id="results-shortocde"></div>
      <?php } else {?>
      <ul class="form-elements noborder">
        <li class="to-label"></li>
        <li class="to-field">
          <input type="hidden" name="cs_orderby[]" value="register" />
          <input type="button" value="Save" style="margin-right:10px;" onclick="javascript:_removerlay(jQuery(this))" />
        </li>
      </ul>
      <?php }?>
    </div>
    </div>
</div>
<?php
		if ( $die <> 1 ) die();
	}
	add_action('wp_ajax_cs_pb_register', 'cs_pb_register');
}