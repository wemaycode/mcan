<?php
/**
 * File Type : Login Shortcodes
 * @copyright Copyright (c) 2014, Chimp Studio 
 */


//=====================================================================
// User Login Ajax Function
//=====================================================================

if ( ! function_exists( 'cs_get_login_nav_shortocde' ) ) {
	function cs_get_login_nav_shortocde(){
		$cs_theme_options	=  get_option('cs_theme_options');
		$cs_login_options = $cs_theme_options['cs_login_options'];
		echo '<li>';    
			if(isset($cs_login_options) and $cs_login_options=='on'){ 
			global $current_user;
			$uid= $current_user->ID;
			
			$isRegistrationOn = get_option('users_can_register');
		    $isRegistrationOnClass	= '';
			
			if ( !$isRegistrationOn ) {
				$isRegistrationOnClass	= 'no_icon';
			}
				if ( is_user_logged_in() ) {
					echo '<a class="cs-user-login"><i class="fa fa-user"></i>'.get_the_author_meta('display_name',$uid).'<i class="fa fa-angle-down"></i></a>';
				}else{
					echo '<a class="cs-users" data-target="#aweken_login" data-toggle="modal"><i class="fa fa-user"></i>'.__('User Login ','Cause').'</a>';
				}
				cs_login_section();	
			}
	   echo '</li>';
		
	}
}
add_shortcode('cs_get_login_nav', 'cs_get_login_nav_shortocde');

//======================================================================
// Register Shortcode
//======================================================================
if (!function_exists('cs_register_shortcode')) {
	function cs_register_shortcode($atts, $content = "") {
		global $wpdb, $cs_theme_options;
		$defaults = array('column_size'=>'1/1','register_title'=>'','register_text'=>'','register_role' => 'contributor','cs_register_class'=>'','cs_register_animation'=>'');
		extract( shortcode_atts( $defaults, $atts ) );
		$column_class  = cs_custom_column_class($column_size);
		
		$user_disable_text = __('User Registration is disabled','Awaken');
		
		$output = '';
		$CustomId = '';
		
		$rand_id = rand(5,99999);
		
		if ( is_user_logged_in() ){
			$output .= 
			'<div class="registor-log"> 
				<a href="'.wp_logout_url("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']).'">
					<i class="fa fa-sign-out"></i>
				</a>
				<h2 class="warning">'.__("You must be logged out for registration.", "Awaken").'</h2>
			</div>';
		}else{
		
		$role = $register_role;
		
		$output .='
		  <div class="col-md-6 register-page '.$cs_register_class.' '.$cs_register_animation.'">
            <section class="cs-signup" style="display:block;">
                <div class="login-from login-form-id-'.$rand_id.'">
                    <h2>'.__('Sign In','Awaken').'</h2>
                    <form method="post" class="wp-user-form webkit" id="ControlForm_'.$rand_id.'">
                        <fieldset>
                            <p> 
                            <span class="input-icon"><i class="fa fa-user"></i>
                                <input type="text" name="user_login" size="20" id="user_login" tabindex="11" onfocus="if(this.value ==\'Username\') { this.value = \'\'; }" onblur="if(this.value == \'\') { this.value =\'Username\'; }" value="Username" />
                            </span> 
                            </p>
                            <p> 
                            <span class="input-icon"><i class="fa fa-unlock-alt"></i>
                            <input type="password" name="user_pass" size="20" id="user_pass" tabindex="12" onfocus="if(this.value ==\'User Name\') { this.value = \'\'; }" onblur="if(this.value == \'\') { this.value =\'User Name\'; }" value="User Name" />
                            </span> 
                            </p>
                            <p> 
                            <input name="rememberme" value="forever" type="checkbox">
                            '.__('Remember me','Awaken').'
                            <span class="status status-message" style="display:none"></span>
                            </p>
                            <p>
                            <input type="button" name="user-submit" class="user-submit backcolr"  value="'.__('Log in','Awaken').'" onclick="javascript:cs_user_authentication(\''.admin_url("admin-ajax.php").'\',\''.$rand_id.'\')" />
                            <input type="hidden" name="redirect_to" value="'.get_permalink().'" />
                            <input type="hidden" name="user-cookie" value="1" />
                            <input type="hidden" value="ajax_login" name="action">
                            <input type="hidden" name="login" value="login" />
                            </p>
                        </fieldset>
                    </form>
                </div>
                <h6 class="forget-link">
                <a href="'.wp_lostpassword_url( ).'">
                '.__('Forget Password','Awaken').'
                </a>
                </h6>';
				ob_start();
                if( class_exists( 'wp_causes' ) ){ $output .= do_action('login_form'); }
				$output .= ob_get_clean();
			$output .= '
            </section>
		   </div>';
		   
		   $isRegistrationOn = get_option('users_can_register');
		   if ( $isRegistrationOn ) {
           
           $output .='
		   <div class="col-md-6 register-page '.$cs_register_class.' '.$cs_register_animation.'">
				
				<div class="cs-user-register">
				  <h2>'.$register_title.'</h2>
				  <form method="post" class="wp-user-form" id="wp_signup_form_'.$rand_id.'" enctype="multipart/form-data">
				
					<ul class="upload-file">
					  <li>
					  <i class="fa fa-user"></i>
						<input type="text" name="user_login" size="20" tabindex="101" onfocus="if(this.value ==\'UserName\') { this.value = \'\'; }" onblur="if(this.value == \'\') { this.value =\'UserName\'; }" value="UserName" />
					  </li>
					  <li>
					  <i class="fa fa-envelope"></i>
						<input type="text" name="user_email" size="25" id="user_email" tabindex="101" onfocus="if(this.value ==\'Email\') { this.value = \'\'; }" onblur="if(this.value == \'\') { this.value =\'Email\'; }" value="Email" />
					  </li>
					</ul>
					<ul class="upload-file">
					  <li>';
					  ob_start();
					  $output .= do_action('register_form');
					  $output .= ob_get_clean();
						$output .= '
						<input type="button" name="user-submit" id="submitbtn" value="'.__('Sign Up','Awaken').'" class="user-submit" tabindex="103" onclick="javascript:cs_registration_validation(\''.admin_url("admin-ajax.php").'\',\''.$rand_id.'\')" />
						<div id="result_'.$rand_id.'" class="status-message"><p class="status"></p></div>
						<input type="hidden" name="role" value="'.$role.'" />
						<input type="hidden" name="action" value="cs_registration_validation" />
					  </li>
					</ul>
				  </form>
				  <div class="register_content">'.do_shortcode($content.$register_text).'</div>
				</div>
			</div>';
		  } else {
          $output .='
			<div class="col-md-6 register-page">
				 <div class="cs-user-register">
					  <div class="cs-section-title">
						<h2>Register</h2>
					  </div>
					  <p>'.$user_disable_text.'</p>
				 </div>
		   </div>';
           
		  }
		}
			
		return $output;
	}
	add_shortcode('cs_register', 'cs_register_shortcode');
}
?>