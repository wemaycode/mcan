<?php
/**
 * The template for Cause Detail
 * @copyright Copyright (c) 2014, Chimp Studio 
 */
global $cs_node,$post,$cs_theme_options,$cs_counter_node;
$cs_uniq = rand(40, 9999999);
if ( is_single() ) {
	cs_set_post_views($post->ID);
}	
$cs_node = new stdClass();
get_header();
$cs_layout = '';
$leftSidebarFlag	= false;
$rightSidebarFlag	= false;
?>
<!-- Page Cause Start -->

<section class="page-section" style=" padding: 0; "> 
  <!-- Container -->
  <div class="container"> 
    <!-- Row -->
    <div class="row">
      <?php
	if (have_posts()):
		while (have_posts()) : the_post();	
		
		$cs_tags_name = 'causes-tag';
		$cs_categories_name = 'causes-category';
		$postname = 'causes';
		$cs_cause = get_post_meta($post->ID, "cs_cause_meta", true);
		$paypal_currency_sign = isset($cs_theme_options['paypal_currency_sign'])?$cs_theme_options['paypal_currency_sign']:'$';	
			if ( $cs_cause <> "" ) {
				$cs_xmlObject = new SimpleXMLElement($cs_cause);
				$cs_layout 			= $cs_xmlObject->sidebar_layout->cs_page_layout;
				$cs_sidebar_left 	= $cs_xmlObject->sidebar_layout->cs_page_sidebar_left;
				$cs_sidebar_right   = $cs_xmlObject->sidebar_layout->cs_page_sidebar_right;
				if(isset($cs_xmlObject->cs_related_post))
					$cs_related_post = $cs_xmlObject->cs_related_post;
				else 
					$cs_related_post = '';
				if(isset($cs_xmlObject->post_pagination_show))
					 $post_pagination_show = $cs_xmlObject->post_pagination_show;
				else 
					$post_pagination_show = '';
				if(isset($cs_xmlObject->post_author_info_show))
					 $cs_post_author_info_show = $cs_xmlObject->post_author_info_show;
				else 
					$cs_post_author_info_show = '';
				if(isset($cs_xmlObject->post_tags_show))
					 $post_tags_show = $cs_xmlObject->post_tags_show;
				else 
					$post_tags_show = '';
				if ( $cs_layout == "left") {
					$cs_layout = "page-content";
					$leftSidebarFlag	= true;
				}
				else if ( $cs_layout == "right" ) {
					$cs_layout = "page-content";
					
					$rightSidebarFlag	= true;
				}
				else {
					$cs_layout = "col-md-12";
				}
				$postname = 'causes';
			}else{
				$cs_layout 	=  isset($cs_theme_options['cs_single_post_layout'])?$cs_theme_options['cs_single_post_layout']:'';;
				if ( isset( $cs_layout ) && $cs_layout == "sidebar_left") {
					$cs_layout = "page-content causes-detail";
					$cs_sidebar_left	= $cs_theme_options['cs_single_layout_sidebar'];
					$leftSidebarFlag	= true;
				} else if ( isset( $cs_layout ) && $cs_layout == "sidebar_right" ) {
					$cs_layout = "page-content causes-detail";
					$cs_sidebar_right	= $cs_theme_options['cs_single_layout_sidebar'];
					$rightSidebarFlag	= true;
				} else {
					$cs_layout = "col-md-12";
				}
  				$post_pagination_show = 'on';
				$post_tags_show = $cs_post_author_info_show = '';
				$cs_related_post = '';
				$postname = 'causes';
				$cs_post_social_sharing = '';
			}
			if ($cs_cause <> "") {
				$cs_xmlObject = new SimpleXMLElement($cs_cause);
				$cs_post_social_sharing  = $cs_xmlObject->post_social_sharing;
				$cause_goal_amount = ($cs_xmlObject->cause_goal_amount<>'' )? $cs_xmlObject->cause_goal_amount:0;
				$cause_end_date = isset($cs_xmlObject->cause_end_date)?strtotime($cs_xmlObject->cause_end_date):strtotime(get_the_date());
				$cause_paypal_email = $cs_xmlObject->cause_paypal_email;
				$cs_donations_show = $cs_xmlObject->cs_donations_show;
			} else {
				$cs_xmlObject = new stdClass();
				$cause_goal_amount = $cause_raised_amount = $cs_post_social_sharing  = $cause_end_date = $cause_paypal_email = $cs_donations_show ='';
			}
			  $goal_percent= 0;
			  $cause_raised_amount = get_post_meta($post->ID, "cs_cause_raised_amount", true);
			  $cause_raised_amount = ($cause_raised_amount <>'')?$cause_raised_amount:0;
			  if($cause_goal_amount <> 0 and $cause_goal_amount <> ''){
				  $goal_percent = get_post_meta($post->ID, "cs_cause_percentage_amount", true).'%';
			  }
		$width = 844;
		$height = 475;
		$image_url = cs_get_post_img_src($post->ID, $width, $height);
		?>
      <!--Left Sidebar Starts-->
      <?php if ($leftSidebarFlag == true){ ?>
      <aside class="page-sidebar">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar($cs_sidebar_left) ) : ?>
        <?php endif; ?>
      </aside>
      <?php } ?>
      <!--Left Sidebar End--> 
      <script type="text/javascript">
	  		jQuery(document).ready(function(){
				cs_progress_bar();
			});
		</script>
      <!-- Cause Detail Start -->
      <div class="<?php echo esc_attr($cs_layout); ?> causes-detail"> 
        <!-- Cause Start --> 
        <!-- Row -->
        <div class="col-md-12">
		 		<?php if($image_url <> ''){ ?>
                        <figure class="detailpost"><img src="<?php echo esc_url($image_url); ?>" alt="Cause"></figure>
                <?php } ?>
				<div class="post-option-panel">
                        <div class="progres-desc">
                            <div class="progress-top">
                              		<span class="raising"> <strong><?php echo cs_validate($paypal_currency_sign.number_format(absint($cause_raised_amount)));?></strong>
                               			<?php _e(' Raised','Cause');?>
                              		</span>
								<?php if($cause_goal_amount <> ''){?>
                              		<span class="goal"><?php _e('Goal ','Cause'); echo cs_validate($paypal_currency_sign.number_format(absint($cause_goal_amount)));?></span>
                                 <?php } ?>
                              <ul class="post-option">
                              <li class="post-<?php echo intval($post->ID);?>">
                              <?php
                              		$user = cs_get_user_id();
									$cs_wishlist = array();
									$cs_wishlist =  get_user_meta(cs_get_user_id(),'cs-cause-wishlist', true);
									if(isset($user) and $user<>'' and is_user_logged_in()){
										$cs_wishlist = get_user_meta(cs_get_user_id(),'cs-cause-wishlist', true);
										if(is_array($cs_wishlist) && in_array($post->ID,$cs_wishlist)){
											echo '<a class="cs-add-wishlist" ><i class="fa fa-plus cs-bgcolr"></i>'.__('Already in Wishlist','Cause').'</a>';
									}else{
									?>
									<a class="cs-add-wishlist" onclick="cs_addto_wishlist('<?php echo esc_url(admin_url('admin-ajax.php'));?>','<?php echo intval($post->ID);?>','post')">
										<i class="fa fa-heart"></i> 
										<?php _e('Add to Wishlist','Cause');?>
									</a>
							<?php } 
							}else{?>
									<a class="cs-add-wishlist" onclick="cs_addto_wishlist('<?php echo esc_url(admin_url('admin-ajax.php'));?>','<?php echo intval($post->ID);?>','post')">
										<i class="fa fa-heart"></i> 
										<?php _e('Add to Wishlist','Cause');?>
									</a>	
						<?php } ?>
                            </li>
                              <?php
							  if($cause_end_date <> ''){ ?>
                                <li>
                                  <time datetime="<?php echo date_i18n('dmy',$cause_end_date); ?>">
                                    <i class="fa fa-calendar"></i>
                                    	<?php echo date_i18n(get_option('date_format'),$cause_end_date); ?>
                                  </time>
                                </li>
                                <?php
							  	}
								 $categories_list = get_the_term_list ( get_the_id(), 'causes-category', ':' , ', ', '' );
									if ( $categories_list ){
									?>
                                    	<li>
										<i class="fa fa-folder-o"></i>
									<?php 
											printf( __( '%1$s', 'Cause'),$categories_list );
									?>
										</li>
								  <?php } ?>
                              </ul>
                            </div>
                            
                            <div class="patteren">
                            	<div class="progres-box">
                                	<div data-percent="<?php echo cs_validate($goal_percent); ?>" class="skillbar">
                                    <div class="skillbar-bar">
                                      <small><?php echo cs_validate($goal_percent); _e(' of goal','Cause');?></small>
                                    </div>
                              </div>
                                <!--patteren--> 
                              	</div>
                            </div>
                            <a href="#" class="btn cs-btn-donate cs-bgcolrhvr" data-toggle="modal" data-target="#CausemyModal2<?php echo intval($post->ID);?>"><?php _e('Donate Now','Cause');?></a>
                          </div>
                          <div class="rich_editor_text">				
							<?php
								the_content();
							?>
                           </div>
            </div>
            <?php if ($cs_donations_show == 'on' ){ ?>
            <div class="cs-section-title">
                <h2><?php _e('Cause Doners','Cause')?></h2>
            </div>
            <ul class="cs-doners">
            	<?php
							$counter_donation=1;
							$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
							
					  if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0 ) {
						  foreach ( $cs_cause_trans[$post->ID] as $transct ){
								  $user_id = $transct['user_id'];
								  $address_name = $transct['address_name'];
								  $payer_email = $transct['payer_email'];
								  $payment_gross = $transct['payment_gross'];
								  $txn_id = $transct['txn_id'];
								  $payment_date = $transct['payment_date'];
								  echo '<li><span class="counter">'.$counter_donation.'</span><a>'.$address_name.'</a><p><span>'.$paypal_currency_sign.$payment_gross.'</span><a>'.__('Donation','Cause').'</a></p></li>';
								  $counter_donation++;
						  }
					  }
				?>
            </ul>
			<?php
				}
						 $thumb_ID = get_post_thumbnail_id( $post->ID );
						 if ( $images = get_children(array(
						   'post_parent' => get_the_ID(),
						   'post_type' => 'attachment',
						  // 'post_mime_type' => 'image',
						   'exclude' => $thumb_ID,
						  )))  
						//echo '<pre>';
						if(is_array($images))	{  
					?>
						  <div class="cs-attachments">
						  <h5> <?php _e('Attachments','Cause');?> </h5>
							<ul>
								<?php 
							  foreach( $images as $image ) {  ?>
								<li>
								<?php if ( $image->post_mime_type == 'image/png' 
										|| $image->post_mime_type == 'image/gif' 
										|| $image->post_mime_type == 'image/jpg'
										|| $image->post_mime_type == 'image/jpeg'
									  ) { 
										$image_url = cs_attachment_image_src($image->ID, 370, 208 );
										?>
										 <figure> <a href="<?php echo esc_url($image->guid);?>"><img src="<?php echo esc_url($image_url);?>" alt="<?php echo esc_attr($image->post_name);?>"></a> </figure>
										 <?php } else if ( $image->post_mime_type == 'application/zip' ) { ?>
														<figure> <a href="<?php echo esc_url($image->guid);?>"><i class="fa fa-file-zip-o"></i></a> </figure>
										 <?php }else if ( $image->post_mime_type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) { ?>
														<figure> <a href="<?php echo esc_url($image->guid);?>"><i class="fa fa-file-word-o"></i></a> </figure>
										 <?php } else if ( $image->post_mime_type == 'text/plain' ) { ?>
														<figure> <a href="<?php echo esc_url($image->guid);?>"><i class="fa fa-file-text"></i></a> </figure>
										 <?php } else if ( $image->post_mime_type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ) { ?>
														<figure> <a href="<?php echo esc_url($image->guid);?>"><i class="fa fa-file-excel-o"></i></a> </figure>
										 <?php } else { ?>
														<figure> <a href="<?php echo esc_url($image->guid);?>"><i class="fa fa-align-justify"></i></a> </figure>
										 <?php } ?>
									<div class="text"> <a href="<?php echo esc_url($image->guid);?>"><?php echo esc_url($image->post_name);?></a> </div>
								</li>
							<?php } ?>
						  </ul>
					   </div>
					<?php } ?>
        	</div>
          <!-- Col Tags Start -->
          <div class="col-md-12">
            <div class="detail-post">
			 <?php if(isset($post_tags_show) &&  $post_tags_show == 'on'){
				 		if ( empty($cs_xmlObject->post_tags_show_text) ) $post_tags_show_text = __('Tags', 'Cause'); else $post_tags_show_text = $cs_xmlObject->post_tags_show_text;
				 		 $categories_list = get_the_term_list ( get_the_id(), 'causes-tag', '<li>', '</li><li>', '</li>' );
				  		if ( isset($categories_list) and $categories_list<>'' ){ ?>
                        <!-- cs Tages Start -->
                              <div class="cs-tags">
                                <div class="cs-title"><a href="#"><i class="fa fa-tags"></i><?php echo esc_attr($post_tags_show_text);?></a></div>
                                <ul>
                                       <?php printf( __( '%1$s', 'Cause'),$categories_list ); ?>
                                </ul>
                              </div>
			 		<?php  } 
			 
			 		} ?>
              <!-- cs Tages End -->
              <div class="socialmedia">
                 <?php  
			  		if ($cs_post_social_sharing == "on"){
						if ( empty($cs_xmlObject->post_social_sharing_text) ) $post_social_sharing_text = __('Share', 'Cause'); else $post_social_sharing_text = $cs_xmlObject->post_social_sharing_text;
                       	cs_social_share(false,true,$post_social_sharing_text);
				 } ?>
              </div>
            </div>
          </div>
          <!-- Cause next/prev Button Start-->
          <?php if(isset($post_pagination_show) &&  $post_pagination_show == 'on'){
				echo '<div class="col-md-12">';
							px_next_prev_custom_links($postname);
				echo '</div>';
             }
          ?>
         <!-- Col Author Start -->
          <?php if(isset($cs_post_author_info_show) &&  $cs_post_author_info_show == 'on'){ ?>
          		<div class="col-md-12">
			 		<?php cs_author_description('show');?>    
          		</div>
          <!-- Col Author End --> 
          <?php } ?>
          <!-- Col related Cause Start -->
          <?php if($cs_related_post =='on'){
				if ( empty($cs_xmlObject->cs_related_post_title) ) $cs_related_post_title = __('Related Causes', 'Cause'); else $cs_related_post_title = $cs_xmlObject->cs_related_post_title;
						 ?>
          <div class="col-md-12 post-recent">
            <div class="row">
              <?php
			  	wp_reset_query();
				  $custom_taxterms='';
				  $width  = 370;
				  $height = 208;
				  $custom_taxterms = wp_get_object_terms( $post->ID, array($cs_categories_name, $cs_tags_name), array('fields' => 'ids') );
				  $args = array(
					  'post_type' => $postname,
					  'post_status' => 'publish',
					  'posts_per_page' => 3,
					  'orderby' => 'DESC',
					  'tax_query' => array(
						  'relation' => 'OR',
						  array(
							  'taxonomy' => $cs_tags_name,
							  'field' => 'id',
							  'terms' => $custom_taxterms
						  ),
						  array(
							  'taxonomy' => $cs_categories_name,
							  'field' => 'id',
							  'terms' => $custom_taxterms
						  )
					  ),
					  'post__not_in' => array ($post->ID),
				  );
				 $custom_query = new WP_Query($args);
				 if($custom_query->have_posts()){
				echo '<div class="col-md-12">
						<div class="cs-section-title">
							<h2>'. $cs_related_post_title.'</h2>
						</div>
					 </div>';
					 while ($custom_query->have_posts()) : $custom_query->the_post();
					 $cs_cause = get_post_meta($post->ID, "cs_cause_meta", true);	
						if ( $cs_cause <> "" ) {
							$cs_xmlObject = new SimpleXMLElement($cs_cause);
							$cause_goal_amount = ($cs_xmlObject->cause_goal_amount<>'' )? $cs_xmlObject->cause_goal_amount:0;
						}
						$goal_percent= 0;
						$cause_raised_amount = get_post_meta($post->ID, "cs_cause_raised_amount", true);
						$cause_raised_amount = ($cause_raised_amount<>'')?$cause_raised_amount:0;
						if($cause_goal_amount<>0 and $cause_goal_amount<> ''){
							$goal_percent = get_post_meta($post->ID, "cs_cause_percentage_amount", true).'%';
						}
						$image_url = cs_get_post_img_src($post->ID, $width, $height);
						if($image_url == ''){
							$img_class = 'no-image';	
							$image_url	= get_template_directory_uri().'/assets/images/no-image16x9.jpg';
						}else{
							$img_class  = '';
						}						 
						?>
						<div class="col-md-4">
						  <!-- Article -->
						  <article class="cs-causes cs-grid has_shapes"> 
							<?php if($image_url <> ""){?>
							   <figure class="<?php echo esc_attr($img_class);?>"><a href="<?php the_permalink(); ?>"><img alt="cause" src="<?php echo esc_url($image_url);?>"></a>
							   </figure>
							<?php }?>
                                <section class="text">
                                    <h2>
                                        <a href="<?php the_permalink(); ?>"><?php echo substr(get_the_title(),0,20); ?></a>
                                    </h2>
                                      <p><?php echo cs_get_the_excerpt(100,false); ?></p>
                                      <div class="skills-sec">
                                          <div class="cs-progres-bar">
                                              <div class="cs-amount">
                                                  <span class="raised-amount"><?php echo cs_validate($paypal_currency_sign.number_format($cause_raised_amount)); _e(' Raised','Cause');?></span>
                                                  <?php if($cause_goal_amount<>''){ ?>
                                                  		<span class="goal-amount"><?php _e('Goal ','Cause'); echo cs_validate($paypal_currency_sign.number_format(absint($cause_goal_amount)));?></span>
                                                  <?php } ?> 
                                              </div>
                                          	<div class="cs-skillbar">
                                              <div data-percent="<?php echo cs_validate($goal_percent);?>" class="skillbar">
                                                <div class="skillbar-bar" style="width: <?php echo cs_validate($goal_percent); ?>;"> </div>
                                              </div>
                                            </div>
                                          </div>
                                      </div>
                                  </section>
						  </article>
						  <!-- Article Close -->
					    </div>
					  <?php endwhile; 
					  wp_reset_query();
				}
			  ?>
         	 </div>
          </div>
       <?php } ?>
          <!-- Col Comments Start -->
		  <?php // comments_template('', true); ?>
          <!-- Col Comments End --> 
      <!-- Cause Detail End --> 
      <!-- Right Sidebar Start --> 
      </div>
	  <?php endwhile; endif; ?>
    	<?php if ($rightSidebarFlag == true){ ?>
      		<aside class="page-sidebar">
       			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar($cs_sidebar_right) ) : endif; wp_reset_query();?>
      		</aside>
      <?php } ?>
      <!-- Right Sidebar End -->
  	</div>
  </div>
</section>
<!-- PageSection End --> 
<?php 
	if(isset($cs_xmlObject->cause_paypal_email) && $cs_xmlObject->cause_paypal_email <> ''){
		cs_donate_button($cs_xmlObject->cause_paypal_email);
	} else {
		cs_donate_button();
	}
?>

<!-- Footer -->
<?php 
get_footer();