<?php
function cs_user_profile_link($page_id = '', $profile_page = '', $uid = ''){
	if(!isset($page_id) or $page_id == ''){
		$user_link = home_url().'?author='.$uid;
	} else {
		$user_link = add_query_arg( array('action'=>$profile_page,'uid'=>$uid), get_permalink($page_id) );
	}
	return esc_url($user_link);
}

// Profile Menu
function cs_profile_menu($action = '',$uid = ''){
	global $current_user, $wp_roles,$userdata,$cs_theme_options,$post;
	$user_role = get_the_author_meta('roles',$uid );
	$cs_page_id = $cs_theme_options['cs_dashboard'];
	$cs_cause_plugin = get_option('cs_cause_plugin_activation');
	?>
    <ul class="cs-user-menu">
        <li <?php if($action == 'dashboard'){ echo 'class="active"'; }?>>
            <a href="<?php echo cs_user_profile_link($cs_page_id, 'dashboard', $uid); ?>">
            <i class="fa fa-user"></i><?php _e('Profile','Cause'); ?></a>
        </li>
       <?php
            if ( is_user_logged_in() and $current_user->ID == $uid) {?>
        	 <li <?php if($action  == 'compaigns'){ echo 'class="active"'; } ?>>
                <a href="<?php echo cs_user_profile_link($cs_page_id, 'compaigns', $uid); ?>">
                    <i class="fa fa-angellist"></i><?php _e('Campaigns','Cause'); ?>
                </a>
            </li>
            <li <?php if($action  == 'favourites'){ echo 'class="active"'; } ?>>
                <a href="<?php echo cs_user_profile_link($cs_page_id, 'favourites', $uid); ?>">
                    <i class="fa fa-star-half-o"></i><?php _e('Favorites','Cause'); ?>
                </a>
            </li>
           <li <?php if(isset($_GET['action']) && $_GET['action'] == 'donations'){ echo 'class="active"'; } ?>>
                <a href="<?php echo cs_user_profile_link($cs_page_id, 'donations', $uid); ?>">
                    <i class="fa fa-database"></i><?php _e('Donations','Cause');?>
                </a>
            </li>
            <li <?php if($action  == 'profile-setting'){ echo 'class="active"'; } ?>>
                <a href="<?php echo cs_user_profile_link($cs_page_id, 'profile-setting', $uid); ?>">
                    <i class="fa fa-cog"></i><?php _e('Profile Settings','Cause'); ?>
                </a>
            </li>
            <?php 
             if ( is_user_logged_in() ) {
				echo ' <li class="cs-user-logout" ><a href="'.wp_logout_url("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']).'">
				<i class="fa fa-user"></i>'.__('Logout','Cause').'</a></li>';
			}
          }?> 
     </ul>
<?php
}

// User Avatar
if ( ! function_exists( 'cs_user_avatar' ) ) {	
 function cs_user_avatar(){
	if(is_user_logged_in() && isset($_FILES['user_avatar'])){
			$maxi_avatar_width = 300;
			$maxi_avatar_height = 300;
		  require_once ABSPATH.'wp-admin/includes/file.php';
		  $current_user_id = get_current_user_id();
		  $cs_allowed_image_types = array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
		  );
		 $status = wp_handle_upload($_FILES['user_avatar'], array('mimes' => $cs_allowed_image_types));
		  if(empty($status['error'])){
			//$resized = image_resize($status['file'], $maxi_avatar_width, $maxi_avatar_height, $crop = true);
			$image = wp_get_image_editor($status['file']);
			  if ( ! is_wp_error( $image ) ) {
				  $image->resize( $maxi_avatar_width, $maxi_avatar_height, true );
				  $saved = $image->save();
			  }
			if(is_wp_error($image))
			  wp_die($image->get_error_message());
			$uploads = wp_upload_dir();
			$resized_url = $uploads['url'].'/'.basename($saved['path']);
			//print_r($resized_url);
			update_user_meta($current_user_id, 'user_avatar_display', esc_url($resized_url));
		  }else{
			wp_die(sprintf(__('Upload Error: %s','Cause'), $status['error']));
		 }
	}	
 }
}

// Rigistration Validation
function cs_registration_validation($atts =''){
	global $wpdb,$cs_theme_options;
 		
		$username = esc_sql($_POST['user_login']);  
		$json	= array();
		if(empty($username)) { 
			$json['type']		=  "error";
			$json['message']	=  "User name should not be empty.";
			echo json_encode( $json );
			exit();
		}
		
		$email = esc_sql($_POST['user_email']); 
		if(empty($email)) { 
			$json['type']		=  "error";
			$json['message']	=  __("Email should not be empty.", "Cause");
			echo json_encode( $json );
			exit();
		}

		if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) { 
			
			$json['type']		=  "error";
			$json['message']	=  __("Please enter a valid email.", "Cause");
			echo json_encode( $json );
			die;
		}
		 $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
 		 $role = esc_sql($_POST['role']);
		 $status = wp_create_user( $username,$random_password, $email );
			if ( is_wp_error($status) ) { 
				$json['type']		=  "error";
				$json['message']	=  __("User already exists. Please try another one.", "Cause");
				echo json_encode( $json );
				die;
			} else {
				global $wpdb;
  				wp_update_user(array('ID'=>esc_sql($status),'role'=>esc_sql($role),'user_status' => 1));
				$wpdb->update(
							  $wpdb->prefix.'users',
							  array( 'user_status' => 1),
							  array( 'ID' => esc_sql($status) )
							);
				update_user_meta( $status, 'show_admin_bar_front', false );
				wp_new_user_notification(esc_sql($status), $random_password);
				$json['type']		=  "success";
				$json['message']	=  __("Please check your email for login details.", "Cause");
				echo json_encode( $json );
				die;
			}
	die();
}
add_action('wp_ajax_cs_registration_validation', 'cs_registration_validation');
add_action('wp_ajax_nopriv_cs_registration_validation', 'cs_registration_validation');
//==================================================================================
// header , footer
/* get user list*/
function cs_getuser_list(){
	global $current_user;
 
	$user_info = get_userdata( $current_user->ID);
	$username = $user_info->display_name;
    $user_url = $user_info->user_url;
    $user_email = $user_info->user_email;
	$usermeta =get_user_meta($current_user->ID);
	//$usermeta= array_map( function( $a ){ return $a[0]; }, $usermeta );
	echo '<div class="cs-user-info"> 
			<img src="'.$usermeta['user_avatar'].'" width="100" height="100" />';
			echo esc_attr($username);
	 		echo esc_url($user_url);
	 		echo '<p>'.$usermeta['description'].'</p>';
	 		echo '<ul>
					<li>'.$usermeta['facebook'].'</li>
					<li>'.$usermeta['twitter'].'</li>
					<li>'.$usermeta['linkedin'].'</li>
					<li>'.$usermeta['pinterest'].'</li>
					<li>'.$usermeta['google_plus'].'</li>
					<li>'.$usermeta['instagram'].'</li>
			</ul>';
	 echo '</div>';
}

//=====================================================================
// User Profile Custom Fields
//=====================================================================
if ( ! function_exists( 'cs_profile_fields' ) ) {
	
	function cs_profile_fields( $userid ) {
		$userfields['tagline']	= 'Tag Line';;	
		$userfields['mobile'] 	= 'Mobile';	
		$userfields['landline'] = 'Landline';
		$userfields['fax']		= 'Fax';	
		$userfields['facebook'] = 'Facebook';	
		$userfields['twitter'] 	= 'Twitter';
		$userfields['linkedin'] = 'Linkedin';
		$userfields['pinterest']= 'Pinterest';
		$userfields['google_plus']= 'Google Plus';
		$userfields['instagram']= 'Instagram';
		$userfields['skype'] = 'Skype';
		$userfields['address']		= 'Home Address';	
		return $userfields;
	}
}

//=====================================================================
// User Profile Contact Options
//=====================================================================
if ( ! function_exists( 'cs_contact_options' ) ) {
	function cs_contact_options( $contactoptions ) {
		global $cs_theme_options;
		// Only show this option to users who can delete other users
		if ( !current_user_can( 'edit_users' ) )
			return;
			$display_img_url = '';
			$display = $display_image = 'block';
			$display_img_url =	get_the_author_meta( 'user_avatar_display', $contactoptions->ID );
			if($display_img_url == ''){
				$display_image = 'none';
			}		
			?>
            <table class="form-table">
              <tbody>
                <tr>
                  <th> <label for="user_switch">
                      <?php _e('Gender', 'Cause' ); ?>
                    </label>
                  </th>
                  <td>
                    <?php 
                    //get dropdown saved value
                    $selected = get_the_author_meta( 'gender', $contactoptions->ID ); 
                    ?>
                    <select name="gender" id="gender">
                      <option value="male" 	<?php cs_selected($selected,'male'); ?> >Male</option>
                      <option value="female" 	<?php cs_selected($selected,'female'); ?>>Female</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th> <label for="user_switch">
                      <?php _e('Display Photo', 'Cause' ); ?>
                    </label>
                  </th>
                  <td><input type="hidden" name="user_avatar_display" id="user_avatar_display"  value="<?php echo get_the_author_meta( 'user_avatar_display', $contactoptions->ID ); ?>" />
                    <input type="button" name="user_avatar_display" class="uploadMedia"  value="Browse" /></td>
                </tr>
                <tr>
                  <td>
                      <div class="page-wrap" style="overflow:hidden; display:<?php echo esc_attr($display_image); ?>" id="user_avatar_display_box" >
                      <div class="gal-active" style="padding-left:0px;">
                        <div class="dragareamain" style="padding-bottom:0px;">
                          <ul id="gal-sortable">
                            <li class="ui-state-default" id="">
                              <div class="thumb-secs"> <img style="width:auto !important" src="<?php echo esc_attr($display_img_url);?>"  id="user_avatar_display_img" width="100" height="150"  />
                                <div class="gal-edit-opts"> <a   href="javascript:del_media('user_avatar_display')" class="delete"></a> </div>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th> <label for="user_switch"> <?php _e('Profile Public ON/OFF', 'Cause' ); ?></label></th>
                  <td><input type="checkbox" name="user_profile_public" id="user_switch" value="1" <?php checked( 1, get_the_author_meta( 'user_profile_public', $contactoptions->ID ) ); ?> /></td>
                </tr>
                <tr>
                  <th> <label for="user_switch">
                      <?php _e('Contact Form ON/OFF', 'Cause' ); ?>
                    </label>
                  </th>
                  <td><input type="checkbox" name="user_contact_form" id="user_contact_form" value="1" <?php checked( 1, get_the_author_meta( 'user_contact_form', $contactoptions->ID ) ); ?> /></td>
                </tr>
              <tbody>
         </table>
	<?php 
	}

}


if ( ! function_exists( 'cs_donation_count' ) ) {
function cs_donation_count(){
	global $cs_theme_options;
	?>
    <div class="user-counter">
    <ul>
      <?php 
	  	$post_count='';
		$user_id = get_current_user_id();
		$args = array(
				  'post_type' => 'causes',
				  'author'    => $user_id,
				  'post_staus'=> 'publish',
				  'posts_per_page' => -1
			  );
			  $query = new WP_Query($args);
			  $post_count = $query->found_posts;
		$post_count = $post_count<>''?$post_count:'0';
	  	if($post_count<>''){
	   ?>
          <li>
            <div class="bg-section" style=" background-color: #ec942c; ">
              <small><?php _e('Cuases','Cause')?></small>
              <big><?php echo intval($post_count); ?></big>
            </div>
          </li>
      <?php } 
	  
	  $cs_wishlist = get_user_meta($user_id,'cs-cause-wishlist', true);
	  $favorites = $cs_wishlist <> ''?count($cs_wishlist):'0';
	  if($favorites <> ''){
	  ?>
     	<li>
         	 <div class="bg-section" style=" background-color: #5f8410;">
            	<small><?php _e('Favorites','Cause')?></small>
            	<big><?php echo intval($favorites); ?></big>
          	</div>
        </li>
      <?php }
	  	$counter = '0' ;
		$payment_gross= '0' ;
		$paypal_currency_sign = $cs_theme_options['paypal_currency_sign'];
	  	$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
		foreach ( $cs_cause_trans as $post_id => $donations_values ){
			if ( isset($post_id) && !empty($post_id)) {
				$post_status = get_post_status( $post_id );
				foreach ( $donations_values as $donations ){
					if(isset($donations['user_id']) && $donations['user_id'] == $user_id){
						$counter++;
						$payment_gross += $donations['payment_gross'];
					}
				}
			}
		}
	if($payment_gross<>''){ ?>
          <li>
            <div class="bg-section" style=" background-color: #ff4554;">
              <small><?php _e('Donated','Cause')?></small>
              <big><?php echo $paypal_currency_sign.$payment_gross?></big>
            </div>
          </li>
     <?php } 
	 
	 	$donation_collected = 0;
	 	$argsss = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> array('publish', 'private'),
				'meta_key'					=> 'cause_organizer',
				'meta_value'				=> $user_id,
				'meta_compare'				=> "=",
			);
			
	  $custom_query = new WP_Query($argsss);
	  if ( $custom_query->have_posts()) {
		  while ( $custom_query->have_posts() ): $custom_query->the_post();
		  		$donation_collected += get_post_meta(get_the_ID(), "cs_cause_raised_amount", true);
		  endwhile;
	  }
	  $donation_collected = $donation_collected<>''?$donation_collected:'0';
	  if($donation_collected<>''){
	  ?>
          <li>
            <div class="bg-section" style=" background-color: #1ea8c6; ">
              <small><?php _e('Donation Collected','Cause')?></small>
              <big><?php echo $paypal_currency_sign.$donation_collected; ?></big>
            </div>
          </li>
      <?php } ?>
    </ul>
</div>
    <?php
	
}
}

//=====================================================================
// User Profile Contact Options Save Function
//=====================================================================
if ( ! function_exists( 'cs_contact_options_save' ) ) {
	function cs_contact_options_save( $user_id ) {
		if ( !current_user_can( 'edit_users' ) )
		return;
		$user_profile_public=isset($_POST['user_profile_public']) and $_POST['user_profile_public'] <> '' ? $_POST['user_profile_public']: '';
		$user_contact_form=isset($_POST['user_contact_form']) and $_POST['user_contact_form'] <> '' ? $_POST['user_contact_form']: '';
		$user_switch=isset($_POST['user_switch']) and $_POST['user_switch'] <> '' ? $_POST['user_switch']: '';
		update_user_meta( $user_id, 'gender', esc_attr($_POST['gender']) );
		update_user_meta( $user_id, 'user_profile_public', esc_attr($user_profile_public));
		update_user_meta( $user_id, 'user_contact_form', esc_attr($user_contact_form) );
		update_user_meta( $user_id, 'user_switch', esc_attr($user_switch) );
		update_user_meta( $user_id, 'user_avatar_display', esc_attr($_POST['user_avatar_display']) );
	}
}