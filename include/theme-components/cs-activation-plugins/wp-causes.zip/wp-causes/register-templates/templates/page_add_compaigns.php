<?php
global $post, $current_user, $cs_theme_options;
if(isset($_GET['uid']) && $_GET['uid'] <> ''){
	 $uid = absint($_GET['uid']);
} else {
	$uid= $current_user->ID;
}
$cs_campaigns_visibility = $cs_theme_options['cs_campaigns_visibility'];
$cs_campaigns_visibility = $cs_theme_options['cs_campaigns_visibility'];

function cs_error_msg( $error_msg ) {
	$msg_string = '<div style="background:#dd3e3b;" class="messagebox messagebox-v1 has-radius alert alert-info align-left no_border" >';
	foreach ($error_msg as $value) {
		if ( !empty( $value ) ) {
			$msg_string .= '<div class="error" style="color:#ffffff;"><i class="fa fa-info-circle"></i> ' . $value . '</div>';
		}
	}
	$msg_string .= '</div>';
	return $msg_string;
}
function cs_upload_file( $upload_data ) {
	include_once ABSPATH . 'wp-admin/includes/media.php';
	include_once ABSPATH . 'wp-admin/includes/file.php';
	include_once ABSPATH . 'wp-admin/includes/image.php';
	$uploaded_file = wp_handle_upload( $upload_data, array('test_form' => false) );
	if ( isset( $uploaded_file['file'] ) ) {
		$file_loc = $uploaded_file['file'];
		$file_name = basename( $upload_data['name'] );
		$file_type = wp_check_filetype( $file_name );
		$attachment = array(
			'post_mime_type' => $file_type['type'],
			'post_title' => preg_replace( '/\.[^.]+$/', '', basename( $file_name ) ),
			'post_content' => '',
			'post_status' => 'inherit'
		);
		$attach_id = wp_insert_attachment( $attachment, $file_loc );
		$attach_data = wp_generate_attachment_metadata( $attach_id, $file_loc );
		wp_update_attachment_metadata( $attach_id, $attach_data );
		return $attach_id;
	}
	return false;
}

if ( isset( $_POST['cs_compaigns_submit'] ) ) {
	$nonce = $_REQUEST['_wpnonce'];
	if ( !wp_verify_nonce( $nonce, 'cs-add-post' ) ) {
		wp_die( __( 'You are not authorised user.','Cause') );
	}

		$errors = array();
       	$size_limit = 50000000;
		$mime = get_allowed_mime_types();
        $cause_title = trim( $_POST['cause_title'] );
        $cause_content = trim( $_POST['cause_content'] );
		 if ( !empty( $_FILES['cs_featured_img'] ) ) {
			$cs_featured_img = $_FILES['cs_featured_img'];
			$featured_name = $_FILES['cs_featured_img']['name'];
			if ( $featured_name ) {
				$tmp_name = $_FILES['cs_featured_img']['tmp_name'];
				$attach_size = $_FILES['cs_featured_img']['size'];
				$attach_type = wp_check_filetype( $featured_name );
				//check file size
				if ( $attach_size > $size_limit ) {
					$errors[] = __( "Featured file is too big", "Cause" );
				}
				//check file type
				if ( !in_array( $attach_type['type'], $mime ) ) {
					$errors[] = __( "Invalid Featured file type" ,"Cause");
				}
			}
		 }
        $tags = '';
        if ( isset( $_POST['cause_tags'] ) ) {
            $cause_tags = $_POST['cause_tags'];
			if ( !empty( $cause_tags ) ) {
				$tags = explode( ',', $cause_tags );
			}
        }
       //validate title
        if ( empty( $cause_title ) ) {
            $errors[] = __( 'Empty post title', 'Cause' );
        } else {
            $cause_title = trim( strip_tags( $cause_title ) );
        }
		$cause_goal_amount = '';
		if ( empty($_POST["cause_goal_amount"]) ) $_POST["cause_goal_amount"] = "";
		if ( empty($_POST["cause_end_date"]) ) $_POST["cause_end_date"] = "";
		if ( empty($_POST["cause_raised_amount"]) ) $_POST["cause_raised_amount"] = "";
		if ( empty($_POST["cause_paypal_email"]) ) $_POST["cause_paypal_email"] = "";
		if ( empty($_POST["cs_donations_show"]) ) $_POST["cs_donations_show"] = "";
		if ( empty($_POST["cause_organizer"]) ) $_POST["cause_organizer"] = "";
		
		
		if(isset($_POST["cause_goal_amount"]))
			$cause_goal_amount = $_POST["cause_goal_amount"];
		
		if(isset($_POST["cause_end_date"]))
			$cause_end_date = $_POST["cause_end_date"];
		
		if(isset($_POST["cause_raised_amount"]))
			$cause_raised_amount = $_POST["cause_raised_amount"];
		
		if(isset($_POST["cause_paypal_email"]))
			$cause_paypal_email = $_POST["cause_paypal_email"];
		
		if(isset($_POST["cause_organizer"]))
			$cause_organizer = $_POST["cause_organizer"];
       //validate post content
        if ( empty( $cause_content ) ) {
            $errors[] = __( 'Empty post content', 'Cause' );
        } else {
            $cause_content = trim( $cause_content );
        }
		if ( isset($_POST['cs_cause_terms_conditions']) &&  !empty($_POST['cs_cause_terms_conditions'])) {
			$cs_cause_terms_conditions = $_POST['cs_cause_terms_conditions'];
        } else {
            $errors[] = __( 'Please Accept the Term & conditions', 'Cause' );
        }
		$cause_categories = array();
		if ( isset($_POST['cause_categories']))
			$cause_categories = $_POST['cause_categories'];
		if(isset($errors) && count($errors)<1){
			$post_author = cs_get_user_id();
			$post_category = array();
			$post_category = $cause_categories;
			if(isset($cs_campaigns_visibility) && $cs_campaigns_visibility == 'publish')
				$post_stat = 'publish';
			else 
				$post_stat = 'private';
			$cause_post = array(
				'post_title' => $cause_title,
				'post_content' => $cause_content,
				'post_status' => $post_stat,
				'post_author' => $post_author,
				'post_type' => 'causes',
				'tags_input' => $tags,
				'post_date' => current_time('Y-m-d h:i:s')
			);
			if ( isset($_POST['compaign']) && !empty($_POST['compaign']))
				$compaign_type = $_POST['compaign'];
			else 
				$compaign_type = 'insert';
			//insert the post
			if(isset($compaign_type) && $compaign_type == 'insert'){
				$post_id = wp_insert_post( $cause_post );
			} else {
				if(isset($_POST['cause_id']) && !empty($_POST['cause_id'])){
					$post_id = $_POST['cause_id'];
					$cause_post['ID'] = $post_id;
					wp_update_post( $cause_post );
				}
			}
			if ( $post_id ) {
				 wp_set_post_terms($post_id,$post_category,'causes-category',true);
				 wp_set_post_terms($post_id,$tags,'causes-tag',true);
				$featured_url = $attachment_url ='';
				//upload attachment to the post
					 if ( !empty( $_FILES['cs_featured_img'] ) ) {
						$cs_featured_img = $_FILES['cs_featured_img'];
						$cs_featured_img_id = cs_upload_file( $cs_featured_img );
						$featured_id = isset( $cs_featured_img_id ) ? intval( $cs_featured_img_id ) : 0;
						if ( $featured_id ) {
							update_post_meta($post_id,'_thumbnail_id',$featured_id);
							//set_post_thumbnail( $post_id, $featured_id );
						}
						$featured_url = wp_get_attachment_url( $cs_featured_img_id );
					 }
					$sxe = new SimpleXMLElement("<cause></cause>");
					if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;  
					if ( function_exists( 'cs_page_options_save_xml' ) ) {
						//$sxe = cs_page_options_save_xml($sxe);
					}
					$payment_gross=0;
					$sxe->addChild('cause_goal_amount', htmlspecialchars($_POST['cause_goal_amount']) );
					$sxe->addChild('cause_end_date', htmlspecialchars($_POST['cause_end_date']) );
					$sxe->addChild('cause_paypal_email', htmlspecialchars($_POST['cause_paypal_email']) );
					$sxe->addChild('cs_donations_show', htmlspecialchars($_POST['cs_donations_show']) );
					$sxe->addChild('cause_organizer', htmlspecialchars($_POST['cause_organizer']) );	
					update_post_meta( $post_id, 'cause_organizer', htmlspecialchars($_POST['cause_organizer']) );
					update_post_meta( $post_id, 'cs_cause_goal_amount', htmlspecialchars($_POST['cause_goal_amount']) );
					update_post_meta( $post_id, 'cause_end_date', htmlspecialchars($_POST['cause_end_date']) );
					update_post_meta( $post_id, 'cs_cause_meta', $sxe->asXML() );
					$sucess_msg = '<div class="success" style="color:#ffffff;"><i class="fa fa-check"></i> ' . __('Post published successfully', 'Cause') . '</div>';
				}
		}
}
$type = 'insert';
$compaign_button_title = 'Create Campaign';
if(isset($_GET['compaign_id']) && !empty($_GET['compaign_id'])){
	$post_id = absint($_GET['compaign_id']);
	$type = 'update';
	$compaign_button_title = 'Update Campaign';
	if($post_id){
		$post_campaign = get_post($post_id);
		$cause_title = $post_campaign->post_title;
		$cause_content = $post_campaign->post_content;
		$cause_categories = array();
		$cause_categories_array = get_the_terms( $post_id, 'causes-category' );
		foreach($cause_categories_array as $categoryy){
			$cause_categories[] = $categoryy->term_id;
		}
		$cause_tags = '';
		$cause_tags_array = get_the_terms( $post_id, 'causes-tag' );
		if(isset($cause_tags_array) && is_array($cause_tags_array) && count($cause_tags_array)>0)
			foreach($cause_tags_array as $causetag){
				$cause_tags .= $causetag->name.', ';
			}
		$cs_cause = get_post_meta($post_id, "cs_cause_meta", true);
		if ( $cs_cause <> "" ) {
			$cs_xmlObject = new SimpleXMLElement($cs_cause);
		}
		$cause_goal_amount = get_post_meta( $post_id, 'cs_cause_goal_amount', true);
		$cause_end_date = get_post_meta( $post_id, "cause_end_date", true);
		$cause_organizer = get_post_meta( $post->ID, 'cause_organizer', true);
		if ( empty($cs_xmlObject->cause_paypal_email) ) $cause_paypal_email = ""; else $cause_paypal_email = $cs_xmlObject->cause_paypal_email;
	}
}
$image_url = '';
if(isset($post_id) && !empty($post_id)){
	$type = 'update';
	$compaign_button_title = 'Update Campaign';
}
?>
<script type="text/javascript">
	jQuery(function(){
		 jQuery('#cause_end_date').datetimepicker({
			  format:'Y/m/d',
			  timepicker:false
		 });
	});
</script>

<?php cs_donation_count(); ?>

<div class="cs-section-title">
    <h2>
	<?php
	if(isset($post_id) && !empty($post_id)){
	 	_e('Update Campaign','Cause');
	} else {
		_e('Add Campaign','Cause');
	}
	 ?>
    </h2>
</div>
<div class="cs-cause-create">
	<?php
		if ( isset($errors) && count($errors)>0 ) {
            echo cs_error_msg( $errors );
        }
		if(isset($sucess_msg) && !empty($sucess_msg)){
		  echo '<div style="background:#aebc49;" class="messagebox messagebox-v1 has-radius alert alert-info align-left no_border">';
			echo balanceTags($sucess_msg, false);
		  echo '</div>';
		}
	?>
     <form id="cs_add_compaign_form" name="cs_compaigns_post_form" action="" enctype="multipart/form-data" method="POST">
      <?php 
	  wp_nonce_field( 'cs-add-post' );
	  if(isset($post_id) && !empty($post_id)){
		echo '<input type="hidden" name="cause_id" value="'.absint($post_id).'" />';  
	  }
	  ?>
        <div class="rich_editor_text has-border">
        	<?php
			if(isset($cs_theme_options['cs_add_compaigns_text']) && $cs_theme_options['cs_add_compaigns_text'] <> ''){
			?>
            	<p><?php echo balanceTags($cs_theme_options['cs_add_compaigns_text'], true);?></p>
            <?php
			}
			if ( current_theme_supports( 'post-thumbnails' ) ) { ?>
            <ul class="upload-file cs-display-bg">
            	<li>
                <div class="browse-sec">
                    <span class="upload-file-icon">
                        <i class="fa fa-image"></i>
                        <input disabled="disabled" class="file-upload" placeholder="Choose File" id="uploadFile">
                    </span>
                    <div class="fileUpload">
                        <span><i class="fa fa-image"></i><?php _e('Upload Photo','Cause')?></span>
                        <input type="file" value="" name="cs_featured_img" class="upload" id="form_user_avatar">
                        <input type="hidden" value="wp_handle_upload" name="action">
                    </div>
                     <script>
					 	document.getElementById("form_user_avatar").onchange = function () {
							document.getElementById("uploadFile").value = this.value;
							if(jQuery('#thubmial-img').length){
								jQuery('#thubmial-img').html(this.value);
								if(jQuery('#thubmial-img img').length){
									jQuery('#thubmial-img img').remove();
								}
								//jQuery('#thubmial-img img').attr("src", this.value);
							}
						};
					</script>
                </div>
              </li>
              <li id="thubmial-img">
              	<?php 
				if (isset($post_id) &&  has_post_thumbnail( $post_id ) ) {
					$thumb_id = get_post_thumbnail_id($post_id);
					?>
					<a onclick="javascript:cs_delete_compaign_thumbnail('<?php echo esc_js(admin_url('admin-ajax.php'));?>','<?php echo esc_js($post_id);?>','<?php echo esc_js($thumb_id);?>')" class="close close-<?php echo intval($post_id); ?>" href="#">×</a>
					<?php
					echo get_the_post_thumbnail( $post_id, 'thumbnail' ); 
				}
				?>
              </li>
        <?php } else { ?>
           <li class="info"><?php _e( 'Your theme doesn\'t support featured image', 'Cause' ) ?></li>
        <?php } ?>
            </ul>
        </div>
        <ul class="upload-file">
        	
            <li class="first_name">
                <label for="Cause"><?php _e('Cause Title','Cause')?></label>
                <div class="inner-sec">
                	<input type="text" name="cause_title" value="<?php if(isset($cause_title)) echo esc_attr($cause_title);?>" class="text-input" placeholder="Title" required="required" >
                </div>
            </li>
            <li class="form-description">
                <label for="description"><?php _e('Description','Cause')?></label>
               	<textarea name="cause_content" id="description" class="text-input"> <?php if(isset($cause_content)) echo esc_attr($cause_content);?></textarea>
            </li>
        </ul>
        <ul class="multiselect-holder upload-file">
            <li class="categories">
                <label for="categories"><?php _e('Categories','Cause')?></label>
                <?php
				if(!isset($cause_categories) || !is_array($cause_categories) || !count($cause_categories)>0){
					$cause_categories = array();
				}
				$args = array(
								'show_option_all'    => '',
								'show_option_none'   => 'Select Categories',
								'orderby'            => 'ID', 
								'order'              => 'ASC',
								'show_count'         => 0,
								'hide_empty'         => 1, 
								'child_of'           => 0,
								'exclude'            => '',
								'echo'               => 1,
								'selected'           => 0,
								'hierarchical'       => 1, 
								'name'               => 'var_course_cat',
								'id'                 => 'categories',
								'class'              => 'dropdown',
								'depth'              => 0,
								'tab_index'          => 0,
								'taxonomy'           => 'causes-category',
								'hide_if_empty'      => false,
								'walker'             => ''
							);
				$categories = get_categories($args); 
				?>
                <select id="categories" class="multiselect" multiple="multiple" name="cause_categories[]">
                    <?php
                    foreach ($categories as $category) {
						$selected = '';
						if(in_array($category->term_id, $cause_categories)){
							$selected = 'selected="selected"';
						}
                        echo '<option value="'.$category->term_id.'" '.$selected.'>' . $category->name . '</option>';
                    }
                    ?>
                </select>
            </li>
        </ul>
        <ul class="upload-file">
            <li class="first_name">
                <label for="Goal"><?php _e('Goal Amount','Cause')?></label>
                <div class="inner-sec">
                    <input type="text" name="cause_goal_amount" id="Goal" value="<?php if(isset($cause_goal_amount)) echo esc_attr($cause_goal_amount);?>" class="text-input">
                </div>
            </li>
            <li class="first_name">
                <label for="Deadline"><?php _e('Deadline','Cause')?></label>
                <div class="inner-sec">
                    <label id="Deadline" class="cs-calendar-combo"><input type="text" id="cause_end_date" name="cause_end_date" value="<?php if(isset($cause_end_date)) echo esc_attr($cause_end_date);?>"><i class="fa fa-calendar"></i></label>
                </div>
            </li>
            <li class="first_name">
                <label for="first_name"><?php _e('Tags','Cause')?></label>
                <div class="inner-sec">
                    <span class="icon-input">
                        <a href="#" id="csload_list"><i class="fa fa-plus"></i></a>
                        
                        <input id="csappend" type="text" value="" class="text-input">
                         <input id="csappend_hidden" name="cause_tags" type="hidden" value="<?php if(isset($cause_tags)) echo esc_attr($cause_tags);?>">
                    </span>
                    <ul class="cs-tags-selection">
                    	<?php
							if(isset($cause_tags) && !empty($cause_tags)){
								$cause_tags = explode(',',$cause_tags);
								foreach($cause_tags as $tag_value){
									if(!empty($tag_value) && trim($tag_value) <> ''){
										echo '<li class="alert alert-warning"><a href="#" class="close" data-dismiss="alert">×</a> <span>'.$tag_value.'</span></li>';
									}
								}
							}
						
						?>
                    		
                    </ul>
                </div>
                <li class="first_name">
                    <label for="Paypal"><?php _e('Organizer Paypal Email','Cause')?></label>
                    <div class="inner-sec">
                        <input name="cause_paypal_email" type="text" value="<?php if(isset($cause_paypal_email)) echo esc_attr($cause_paypal_email);?>" id="cause_paypal_email" class="text-input">
                    </div>
                </li>
                <li class="text-box">
                	<?php
					if(isset($cs_theme_options['cs_compaigns_terms_text']) && $cs_theme_options['cs_compaigns_terms_text'] <> ''){
					?>
						<p><?php echo balanceTags($cs_theme_options['cs_compaigns_terms_text'], true);?></p>
					<?php
					}
					?>
                </li>
                <li>
                    <input id="accept" name="cs_cause_terms_conditions" type="checkbox" <?php //if(isset($cs_cause_terms_conditions) && $cs_cause_terms_conditions == 'accept') echo 'checked';?> />
                    <label for="accept" class="terms-conditions"><?php _e('Accept','Cause')?> <a href="#"><?php _e('Terms and conditions','Cause')?></a></label>
                </li>
                <li>
                    <input type="hidden" name="cs_compaigns_submit" value="yes" />
                    <input id="updateuser" class="submit button cs-bg-color" type="submit" value="<?php echo esc_attr($compaign_button_title);?>">
                     <input type="hidden" name="cause_organizer" value="<?php echo absint($uid);?>" />
     				<input type="hidden" name="compaign" value="<?php echo esc_attr($type);?>" />
                </li>
            </li>
        </ul>
    </form>
</div>
<script type="text/javascript">
	function cs_tags_set_value(){
		var append = jQuery('#csappend').val();
		var hidden_cause = jQuery('#csappend_hidden').val();
		var cause_tags_val = hidden_cause+append+',';
		jQuery('#csappend_hidden').val(cause_tags_val);
		jQuery('ul.cs-tags-selection').append('<li class="alert alert-warning"><a data-dismiss="alert" class="close" href="#">×</a> <span>'+append+'</span></li>');
		jQuery('#csappend').val('');
		
	}
	jQuery(document).ready(function() {
		jQuery('input#csappend').keypress(function(e) {
		  if (e.which == '13') {
			 e.preventDefault();
			 cs_tags_set_value();
			 return false;
		   }
		});
		
		
	    jQuery('#csload_list').click(function() {
			cs_tags_set_value();
	        return false;
	    });
	});
</script>