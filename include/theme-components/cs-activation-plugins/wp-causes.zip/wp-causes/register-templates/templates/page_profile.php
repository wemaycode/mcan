<?php 
/**
 * Template Name: User Profile
  * Allow users to update their profiles from Frontend.
 * @copyright Copyright (c) 2014, Chimp Studio 
 */
	global $current_user, $wp_roles,$userdata, $cs_theme_options;
 	$uid = $current_user->ID;
  	$cs_course_per_page = get_option('posts_per_page');
	$user_role = get_the_author_meta('roles',$uid );
	$cs_counter_node  = 1;
	$cs_page_id = $cs_theme_options['cs_dashboard'];
	$cs_cause_campaigns_allow = $cs_theme_options['cs_cause_campaigns_allow'];
 	if(isset($_GET['uid']) && $_GET['uid'] <> ''){ $uid = $_GET['uid']; }
	$action = (isset($_GET['action']) && $_GET['action'] <> '') ? $_GET['action'] : $action	= '';
	if ( function_exists( 'cs_user_exists' ) ) { cs_user_exists($uid); }
	if ( function_exists( 'get_currentuserinfo' ) ) { get_currentuserinfo();}
	$error = '';
	$flag = 'false';
	
	cs_user_avatar();
	if (empty($_GET['page_id_all'])) $_GET['page_id_all'] = 1;
	
	if ( 'POST' == $_SERVER['REQUEST_METHOD'] && isset( $_POST['action'] ) && $_POST['action'] == 'update-user' && $uid == $current_user->ID) {
		
 		if($current_user->user_login =='demo'){
				$error = __('You are not able to update profile setting from demo account.', 'Cause');
 		}else{
			if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
			
			if ( $_POST['pass1'] == $_POST['pass2'] )
				wp_update_user( array( 'ID' => $uid, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
			else
				$error = __('The passwords you entered do not match.  Your password was not updated.', 'Cause');
			}
		
		if ( !empty( $_POST['email'] ) ){
			if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
 				//update_user_meta( $uid, 'user_email', esc_attr( $_POST['email'] ) );
				wp_update_user( array( 'ID' => $uid, 'user_email' => esc_attr( $_POST['email'] ) ) );
			} else {
				$error = __('Please enter a valid email address.','Cause');
			}
		}
  		 if(isset($_POST['mobile'])) {
			update_user_meta( $uid, 'mobile', esc_attr( $_POST['mobile'] ) );
		 }
		 if(isset($_POST['landline'])) {
			 update_user_meta( $uid, 'landline', esc_attr( $_POST['landline'] ) );
		 }
		 
		if (!$error) { 
			/* Update user information. */
			//update_user_meta( $uid, 'user_avatar_display', $_POST['user_avatar_display'] );
			
			update_user_meta( $uid,'first_name', esc_attr( $_POST['first_name'] ) );
			update_user_meta( $uid,'gender', esc_attr( $_POST['gender'] ) );
			update_user_meta( $uid,'tagline', esc_attr( $_POST['tagline'] ) );
			update_user_meta( $uid, 'user_profile_public', esc_attr($_POST['user_profile_public']) );
			update_user_meta( $uid, 'user_contact_form', esc_attr($_POST['user_contact_form']) );
			//update_user_meta( $uid, 'user_switch', $_POST['user_switch'] );
			update_user_meta( $uid, 'description', html_entity_decode( $_POST['description'] ) );
			/* Extra Profile Information */
			$user_id = wp_update_user( array( 'ID' => $uid, 'user_url' => esc_attr($_POST['website']) ) );
			update_user_meta( $uid, 'facebook', esc_attr( $_POST['facebook'] ) );	
			update_user_meta( $uid, 'twitter', esc_attr( $_POST['twitter'] ) );
			update_user_meta( $uid, 'google_plus',esc_attr( $_POST['google_plus'] ));
			update_user_meta( $uid, 'linkedin', esc_attr($_POST['linkedin']) );	
			update_user_meta( $uid, 'pinterest', esc_attr($_POST['pinterest']) );	
			update_user_meta( $uid, 'skype', esc_attr($_POST['skype']) );
			update_user_meta( $uid, 'instagram', esc_attr($_POST['instagram']) );		
			/* Redirect so the page will show updated info. */
		}
		if (!$error) {
			$flag = 'true';
			}
		}
	}
 	get_header();
	$user_profile_public = get_the_author_meta('user_profile_public',$uid );
	if(isset($user_profile_public) and $user_profile_public=='1'){ 
	}
?>
	<!-- PageSection -->
    <section class="page-section">
        <!-- Container -->
        <div class="container">
            <!-- Row -->
            <div class="row">
            <?php if(isset($user_profile_public) and $user_profile_public=='1' or $current_user->ID ==$uid){ ?>
                 
            <aside class="col-md-3 left-sec">
              <div class="left-sec-holder">
               <article class="st-userinfo">
                <figure>
                    <?php 
						$cs_display_image = '';
						$cs_display_image = get_the_author_meta('user_avatar_display',$uid );
						
						if( $cs_display_image <> ''){?>
							<a class="info-thumb"><img height="134" width="134" src="<?php echo esc_url( $cs_display_image );?>"  /></a>
						<?php }else{?>
							<a class="info-thumb"><?php echo get_avatar(get_the_author_meta('user_email',$uid), apply_filters('PixFill_author_bio_avatar_size', 134));?></a>
						<?php }?>
                        <div class="clear"></div>
                        <ul class="social-media">
							<?php 
                                $facebook = $twitter = $linkedin = $pinterest = $google_plus ='';
                                $facebook = get_the_author_meta('facebook',$uid ); 
                                $twitter  = get_the_author_meta('twitter',$uid );
                                $linkedin = get_the_author_meta('linkedin',$uid );
                                $pinterest = get_the_author_meta('pinterest',$uid );
                                $google_plus = get_the_author_meta('google_plus',$uid );
                                $instagram = get_the_author_meta('instagram',$uid );
                                $skype = get_the_author_meta('skype',$uid );
                                if(isset($facebook) and $facebook <> ''){
                                    echo '<li><a href="'.esc_url($facebook).'" style="background-color:#2d5faa;"><i class="fa fa-facebook"></i></a></li>';
                                }
                                if(isset($twitter) and $twitter <> ''){
                                    echo '<li><a href="'.esc_url($twitter).'" style="background-color:#3ba3f3;"><i class="fa fa-twitter"></i></a></li>';
                                }
                                if(isset($linkedin) and $linkedin <> ''){
                                    echo '<li><a href="'.esc_url($linkedin).'" style="background-color:#2d5faa;"><i class="fa fa-linkedin"></i></a></li>';
                                }
                                if(isset($pinterest) and $pinterest <> ''){
                                    echo '<li><a href="'.esc_url($pinterest).'"  style="background-color:#a82626;"><i class="fa fa-pinterest"></i></a></li>';
                                }
                                if(isset($google_plus) and $google_plus <> ''){
                                    echo '<li><a href="'.esc_url($google_plus).'" style="background-color:#f33b3b;"><i class="fa fa-google-plus"></i></a></li>';
                                }
                                if(isset($skype) and $skype <> ''){
                                    echo '<li><a href="skype:'.esc_url($skype).'?chat" style="background-color:#3ba3f3;"><i class="fa fa-skype"></i></a></li>';
                                }
                                if(isset($instagram) and $instagram <> ''){
                                    echo '<li><a href="'.esc_url($instagram).'"  style="background-color:#f33b3b;"> <i class="fa fa-instagram"></i></a></li>';
                                }
                            ?>                              
                        </ul>
                    </figure>
                <!-- Nav Assigment -->
                 <nav class="cs_assigment_tabs">
					<?php 
                        if ( get_current_user_id()== $uid ){
                                cs_profile_menu( $action,$uid );
                        }
                    ?>
                </nav>
                <!-- Nav Assigment -->
                <div class="text">	
                    <ul>
                        <?php 
                            $cs_mobile = $cs_landline = $cs_email = $cs_skype = $cs_user_url ='';
                            $cs_address = get_the_author_meta('address',$uid ); 
							$cs_mobile = get_the_author_meta('mobile',$uid ); 
                            $cs_landline = get_the_author_meta('landline',$uid );
							$cs_fax = get_the_author_meta('fax',$uid );
                            $cs_email = get_the_author_meta('email',$uid );
                            $cs_skype = get_the_author_meta('skype',$uid );
                            $cs_user_url = get_the_author_meta('user_url',$uid );
							if($cs_address <> ''){
                                echo '<li><i class="fa  fa-home"></i>'.esc_attr( $cs_address ).'</li>';
                            }
							if($cs_mobile <> ''){
                                echo '<li><i class="fa fa-phone"></i>'.esc_attr( $cs_mobile ).'</li>';
                            }
                            if($cs_fax <> ''){
                                echo '<li><i class="fa  fa-fax"></i>'.esc_attr( $cs_fax ).'</li>';
                            }
                            if($cs_email <> ''){
                                echo '<li><i class="fa fa-envelope"></i>'.esc_attr( $cs_email ).'</li>';
                            }
                            if($cs_skype <> ''){
                                echo '<li><i class="fa fa-skype"></i>'.esc_attr( $cs_skype ).'</li>';
                            }
                            if($cs_user_url <> ''){
                                echo '<li><i class="fa fa-link"></i>
                                    <a href="'.esc_url($cs_user_url).'" target="_blank">'.esc_attr( $cs_user_url ).'</a>
                                </li>';
                            }
                        ?>
                    </ul>
                 </div>
               </article>
               <?php if( get_the_author_meta('user_contact_form',$uid) == "1" and  $current_user->ID != $uid /*and isset($current_user->ID) and $current_user->ID <> '0'*/ ){ ?>
               		<div class="cs_form_styling">
                <div class="cs-section-title">
                  <h2><?php echo __('Contact Me','Cause'); ?></h2>
                </div>
               <div class="inputforms respond">
                <div class="textsection">
                    <div class="succ_mess" id="succ_mess<?php echo esc_attr($cs_counter_node)?>"  style="display:none;"></div>
                </div>
                <div class="form-style" id="contact_formZSd">
                <div class="respond fullwidth" id="respond">
					<form id="frm<?php echo esc_attr($cs_counter_node) ?>" name="frm<?php echo esc_attr($cs_counter_node) ?>" method="post" action="javascript:<?php echo "frm_submit".$cs_counter_node."()";?>" novalidate>   
						<p><input type="text" name="contact_name" id="contact_name" class="required" value="Name" onblur="if(this.value == '') { this.value = 'Name'; }" onfocus="if(this.value == 'Name') { this.value = ''; }" /></p>
						<p><input type="text" name="contact_email" id="contact_email" class="required" value="Email Address" onblur="if(this.value == '') { this.value = 'Email Address'; }" onfocus="if(this.value == 'Email Address') { this.value = ''; }" /></p>
						<p><input type="text" name="phone" id="phone" class="required" value="Phone Number" onblur="if(this.value == '') { this.value = 'Phone Number'; }" onfocus="if(this.value == 'Phone Number') { this.value = ''; }" /></p>
						<p><textarea name="contact_msg" id="contact_msg" class="required"></textarea><input type="submit" value="submit" name="submit" class="cs-bg-color" id="submit_btn<?php echo esc_attr($cs_counter_node) ?>"> </p>
						<input type="hidden" name="counter_node" value="<?php echo esc_attr($cs_counter_node) ?>">
                    </form>
                    <span class="form-submit">
						<div id="loading_div<?php echo esc_attr($cs_counter_node) ?>"></div>
						<div id="message<?php echo esc_attr($cs_counter_node) ?>" style="display:none;"></div>
                    </span>
                </div>
               </div>
            </div>
			   <?php 
               $cs_contact_email		= get_the_author_meta( 'user_email', $uid );
               $cs_contact_succ_msg		= 'Email has been sent Successfully.';
               $cs_contact_error_msg	= 'An error Occured, please try again later.';
               cs_enqueue_validation_script(); ?>
                <script type="text/javascript">
                    jQuery().ready(function($) {
                        var container = $('');
                        var validator = jQuery("#frm<?php echo esc_js($cs_counter_node);?>").validate({
                            rules: {
                                 contact_name: "required",
                                 phone: "required",
                                 contact_msg: "required",
                                 contact_email: {
                                   required: true,
                                   email: true
                                 }
                            },
                            messages:{
                                contact_name: '<?php _e('Please enter a username.','Cause');?>',
                                phone: '<?php _e('Please enter a phone number.','Cause');?>',
                                contact_msg: '<?php _e('Please enter a message.','Cause');?>',
                                contact_email:{
                                    required:'<?php _e('Please enter a email address.','Cause');?>',
                                    email:'<?php _e('Please enter a valid email address.','Cause');?>',
                                },
                            },
                            errorContainer: container,
                            errorLabelContainer: jQuery(container),
                            errorElement:'div',
                            errorClass:'frm_error',
                            meta: "validate"
                        });
                    });
                    function frm_submit<?php echo esc_js($cs_counter_node);?>(){
                        var $ = jQuery;
                        $("#loading_div<?php echo esc_js($cs_counter_node);?>").html('<img src="<?php echo get_template_directory_uri()?>/assets/images/ajax-loader.gif" alt="" />');
                        $.ajax({
                            type:'POST', 
                            url: '<?php echo get_template_directory_uri()?>/page_contact_submit.php',
                            data:$('#frm<?php echo esc_js($cs_counter_node);?>').serialize() + "&cs_contact_email=<?php echo esc_js($cs_contact_email);;?>&cs_contact_succ_msg=<?php echo esc_js($cs_contact_succ_msg);?>&cs_contact_error_msg=<?php echo esc_js($cs_contact_error_msg);?>", 
                            dataType: "json",
                            success: function(response) {
                                if (response.type == 'error'){
                                    $("#loading_div<?php echo esc_js($cs_counter_node);?>").html('');
                                    $("#loading_div<?php echo esc_js($cs_counter_node);?>").hide();
                                    $("#message<?php echo esc_js($cs_counter_node);?>").addClass('error_mess');
                                    $("#message<?php echo esc_js($cs_counter_node);?>").show();
                                    $("#message<?php echo esc_js($cs_counter_node);?>").html('<p>'+response.message+'</p>');
                                } else if (response.type == 'success'){
                                    $("#frm<?php echo esc_js($cs_counter_node);?>").slideUp();
                                    $("#loading_div<?php echo esc_js($cs_counter_node);?>").html('');
                                    $("#loading_div<?php echo esc_js($cs_counter_node);?>").hide();
                                    $("#message<?php echo esc_js($cs_counter_node);?>").addClass('succ_mess');
                                    $("#message<?php echo esc_js($cs_counter_node);?>").show();
                                    $("#message<?php echo esc_js($cs_counter_node);?>").html('<p>'+response.message+'</p>');
                                }
                            }
                        });
                    }
                </script>
               </div>
               <?php }?>
              </div>
           </aside>
                <div class="col-md-9">
                    <!-- Row -->
                    <div class="row">
                        <!-- col-md-12 -->
                         <div class="col-md-12">
                            <div id="post-<?php the_ID(); ?>" >
                                <div class="entry-content">
                                    <?php
                                        if (have_posts()):
                                            while (have_posts()) : the_post();
                                                the_content();
                                            endwhile;
                                        endif;
                                        wp_link_pages("\t\t\t\t\t<div class='page-link'>".__('Pages: ', 'Cause'), "</div>\n", 'number');
                                    ?>
                                </div>
                            </div>
                            <?php 
							if((isset($_GET['action']) && $_GET['action'] == 'dashboard') || !isset($_GET['action'])){
							?>
                                <!-- .post -->
                                <?php  $the_author_description = apply_filters("the_content",get_the_author_meta('description',$uid));
                                if (isset ( $the_author_description ) && $the_author_description !='' ) {?>
                                <div class="row">
                                    <div class="rich_editor_text col-md-12">
                                    	<?php cs_donation_count(); ?>
                                        <div class="cs-section-title about-title"><h2><a><?php echo __('About','Cause').' '.get_the_author_meta('display_name',$uid );  ?></a></h2></div>
                                        <p><?php echo balanceTags($the_author_description, true);?></p>
                                    </div>
                                </div>
                                <?php }
                            }
							elseif(isset($_GET['action']) && $_GET['action'] == 'add-compaigns' and $current_user->ID == $uid){
								
								if(isset($cs_cause_campaigns_allow) && $cs_cause_campaigns_allow == 'on'){
									include "page_add_compaigns.php";
								} else {
									if(isset($_GET['compaign_id']) && !empty($_GET['compaign_id']))
										include "page_add_compaigns.php";
									else 
										_e('You are not allowed to create Campaigns','Cause');
								}
							}
							elseif(isset($_GET['action']) && $_GET['action'] == 'compaigns'){
									 cs_donation_count();
									if(isset($uid) && $current_user->ID == $uid){
										include "causes_compaigns.php";
									} else if(isset($user_profile_public) and $user_profile_public=='1'){
										include "causes_compaigns.php";
									} else{
										_e('You are not allowed to Check User Campaigns','Cause');
									}
							}
							elseif(isset($_GET['action']) && $_GET['action'] == 'donations' and $current_user->ID == $uid){
								cs_donation_count();
							   $paypal_currency_sign = $cs_theme_options['paypal_currency_sign'];
								echo '<div class="cs-section-title"><h2>'.__('Donations','Cause').'</h2></div>';
								$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
								?>
								  <div class="cs-donation">
									<div class="toggle-sec">
										<div class="toggle-div">
											<?php
											if ( isset($cs_cause_trans) && is_array($cs_cause_trans) && count($cs_cause_trans)>0 ) {
											?>
												<table>
													<thead>
														<tr>
															<th class="odd">#</th>
															<th class="even"><?php _e('Cause Name','Cause');?></th>
															<th class="odd"><?php _e('Date','Cause');?></th>
															<th class="even"><?php _e('Trasection ID','Cause');?></th>
															<th class="odd"><?php _e('Amount','Cause');?></th>
														</tr>
													</thead>
													<tbody>
													<?php
														$counter = 0;
														foreach ( $cs_cause_trans as $post_id => $donations_values ){
															if ( isset($post_id) && !empty($post_id)) {
																$post_status = get_post_status( $post_id );
																foreach ( $donations_values as $donations ){	
																	if(isset($donations['user_id']) && $donations['user_id'] == $uid){
																		$counter++;
																		if(isset($donations['item_name']) && !empty($donations['item_name']))
																			$item_name = $donations['item_name'];
																		else
																			$item_name = get_the_title($post_id);
																		$address_name = $donations['address_name'];
																		$payment_date = $donations['payment_date'];
																		$txn_id = $donations['txn_id'];
																		$payment_gross = $donations['payment_gross'];
																		if($counter%2==0){
																			$class = 'even';	
																		} else {
																			$class = 'odd';
																		}
																		?>
																		<tr class="<?php echo esc_attr($class);?>">
																			<td><?php echo absint($counter);?></td>
																			<td><a href="<?php echo get_permalink($post_id);?>"><?php echo esc_attr($item_name);?></a></td>
																			<td><?php echo esc_attr($payment_date);?></td>
																			<td><?php echo esc_attr($txn_id);?></td>
																			<td><?php echo esc_attr($paypal_currency_sign.$payment_gross);?></td>
																		</tr>
																		<?php 
																	}
																}
															}
														  }
														?>
													</tbody>
												</table>
												<?php
                                                } else {
                                                    _e('Your donations not found ','Cause');	
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
									}
                               		elseif(isset($_GET['action']) && $_GET['action'] == 'profile-setting' && $current_user->ID == $uid){
										cs_donation_count();
                                    	echo '<div class="cs-section-title"><h2>'.__('Profile Settings','Cause').'</h2></div>';	
                                	?>
                                     <!-- .post -->
                                    <div class="cs-profile-settings">
                                    	<div class="rich_editor_text has-border">
                                    <!-- EDIT PROFILE STARTS HERE -->
                                    <?php 
                                        if ( !is_user_logged_in() ) {
                                            echo '<p class="warning">'.__('You must be logged in to edit your profile.', 'Cause').'</p>';
                                        }else { 
                                            if (!empty($error)){
                                                 echo '<p class="error form-title">' . $error . '</p>';
                                            }else{
                                              if($flag == 'true'){
                                                    echo '<p class="error form-title">'.__('user profile update successfully','Cause').'</p>';
                                              }
                                            }
	                                       	?>
                                              <ul class="upload-file cs-display-bg">
                                                  <li>
                                                     <form method="POST" enctype="multipart/form-data" action="">
                                                       <?php 
															$display_photo = trim(get_the_author_meta( 'user_avatar_display', $uid )); 
															$display = 'none';
															if($display_photo <> ''){
																$display = 'block';	
															}
														?>
                                                         <div class="browse-sec">
                                                            <span class="upload-file-icon">
                                                                <i class="fa fa-image"></i>
                                                                <input id="uploadFile" placeholder="Choose File" class="file-upload" disabled="disabled">
                                                            </span>
                                                            <div class="fileUpload">
                                                                <span><i class="fa fa-image"></i>Upload Photo</span>
                                                                <input type="file" id="form_user_avatar" class="upload" name="user_avatar" value="">
                                                                <input type="hidden" name="action" value="wp_handle_upload">
                                                            </div>
                                                         </div>   
															<script>
                                                                document.getElementById("form_user_avatar").onchange = function () {
                                                                    document.getElementById("uploadFile").value = this.value;
                                                                };
                                                            </script>
                                                            <input type="submit" onclick="javascript:cs_update_profile_image('<?php echo admin_url('admin-ajax.php');?>','<?php echo absint($user_ID) ?>');" value="<?php _e('Update Avatar','Cause')?>" class="cs-bgcolr cs-update-avatar" />
                                                              <div class="page-wrap" style="display:<?php echo esc_attr($display);?>" id="user_avatar_display_box">
                                                                <div class="profile-loading"></div>
                                                                  <div class="gal-active">
                                                                    <div class="dragareamain" style="padding-bottom:0px;">
                                                                      <ul id="gal-sortable">
                                                                        <li class="ui-state-default" id="">
                                                                          <div class="thumb-secs"><i class="fa fa-photo"></i>  <?php echo basename(get_the_author_meta( 'user_avatar_display', $current_user->ID )); ?>
                                                                            <div class="gal-edit-opts"> <a onclick="cs_user_profile_picture_del('user_avatar_display', '<?php echo absint($uid); ?>', '<?php echo admin_url('admin-ajax.php');?>')" class="delete"><i class="fa fa-times"></i></a> </div>
                                                                          </div>
                                                                        </li>
                                                                      </ul>
                                                                    </div>
                                                                  </div>
                                                              </div>
                                                          	  <ul class="cs-hint-text">
                                                            <li> <?php _e('Update your avatar manually,If the not set the default Gravatar will be the same as your login email/user account.','Cause'); ?></li>
                                                            <li> <?php _e(' Max Upload Size: 1MB, Dimensions: 128x128 , Extensions: JPEG,PNG','Cause'); ?></li>
                                                          </ul>
                                                          </form>
                                                          </li>
                                              </ul>
										</div>
										<form method="post" id="edituser" class="user-forms" enctype="multipart/form-data" action="<?php echo get_permalink($cs_page_id); ?>?action=profile-setting&uid=<?php echo absint($uid);?>">
                                             <div class="holder">
                                             	<div class="form-title">
                                                  <h4><?php _e('About me','Cause')?></h4>
                                              </div>
                                              	<ul class="upload-file">
                                                  <li class="first_name">
                                                      <label for="first_name"><?php _e('Full Name', 'Cause'); ?></label>
                                                      <div class="inner-sec">
														<input class="text-input" name="first_name" type="text" id="first_name" value="<?php the_author_meta( 'first_name', $uid ); ?>" />
                                                      </div>
                                                  </li><!-- .first_name -->
                                                  <li class="first_name">
                                                      <label for="gender"><?php _e('Gender', 'Cause'); ?></label>
                                                      <div class="inner-sec">
                                                            <?php $gender=get_the_author_meta( 'gender', $uid ); ?>
                                                            <select name="gender" id="gender">
                                                                <option value="male" 	<?php cs_selected ($gender,'male');?>>Male</option>
                                                                <option value="female" 	<?php cs_selected ($gender,'female');?>>Female</option>
                                                            </select>
                                                          
                                                      </div>
                                                  </li><!-- .first_name -->
                                                  <li class="first_name">
                                                      <label for="tagline"><?php _e('TagLine', 'Cause'); ?></label>
                                                      <div class="inner-sec">
                                                          <input class="text-input" name="tagline" type="text" id="tagline" value="<?php the_author_meta( 'tagline', $uid ); ?>" />
                                                      </div>
                                                  </li><!-- .first_name -->
                                                  <li class="form-description">
                                                      <label for="description"><?php _e('Biography', 'Cause'); ?></label>
                                                      <div class="inner-sec">
                                                          <textarea class="text-input" name="description" id="description" rows="25" cols="30"><?php echo the_author_meta( 'description', $uid ); ?></textarea>
                                                      </div>
                                                  </li>
                                                  <li class="first_name">
                                                        <label><?php _e('Public Profile', 'Cause'); ?></label>
                                                        <div class="inner-sec">
                                                            <div class="button-holder">
                                                             	<input type="hidden" name="user_profile_public" id="user_switch" value="off" />
                                                                <input type="checkbox" id="user_profile_public" name="user_profile_public" class="switch" value="1" <?php checked( get_the_author_meta( 'user_profile_public', $uid),1 ); ?> />
                                                                <span class="switch-text">
                                                                    <label for="user_profile_public"></label>
                                                                </span>
                                                            </div>
                                                        </div>
                                                  </li>
												  <li class="first_name">
                                                    <label><?php _e('Contact Form', 'Cause'); ?></label>
                                                    <div class="inner-sec">
                                                        <div class="button-holder">
                                                            <input type="hidden" name="user_contact_form" id="user_switch" value="off" />	
                                                              <input type="checkbox" class="switch" name="user_contact_form" id="user_contact_form" value="1" <?php checked(get_the_author_meta( 'user_contact_form', $uid ),1 ); ?>>
                                                            <span class="switch-text">
                                                                <label for="user_contact_form"></label>
                                                            </span>
                                                        </div>
                                                        <p><?php esc_html_e('Turn Contact Form ON here to allow users contact you via email', 'Cause'); ?></p>
                                                    </div>
                                                </li>
                                               </ul>
                                             </div>
                                             <div class="holder">   
                                                  <div class="form-title">
                                                      <h4><?php _e('Contact Detail','Cause')?></h4>
                                                  </div>
                                                  <ul class="upload-file">
                                                   <li class="form-twitter">
                                                    <label for="website"><?php _e('Mobile', 'Cause'); ?></label>
                                                    <div class="inner-sec">
                                                      <input class="text-input" name="mobile" type="text" id="mobile" value="<?php the_author_meta( 'mobile', $uid ); ?>" />
                                                    </div>
                                                  </li>
                                                  <li class="form-twitter">
                                                    <label for="website"><?php _e('Landline', 'Cause'); ?></label>
                                                    <div class="inner-sec">
                                                      <input class="text-input" name="landline" type="text" id="landline" value="<?php the_author_meta( 'landline', $uid ); ?>" />
                                                    </div>
                                                   </li>
                                                   <li class="form-email">
                                                      <label for="email"><?php _e('E-mail (required)', 'Cause'); ?></label>
                                                      <div class="inner-sec">
                                                          <input class="text-input" name="email" type="text" id="email" value="<?php the_author_meta( 'user_email', $uid ); ?>" />
                                                      </div>
                                                  </li><!-- .form-email -->
                                                    
                                                 <li class="form-website">
                                                    <label for="website"><?php _e('website', 'Cause'); ?></label>
                                                    <div class="inner-sec">
                                                        <input class="text-input" name="website" type="text" id="website" value="<?php the_author_meta( 'user_url', $uid ); ?>" />
                                                    </div>
                                                  </li>
                                                  <li class="form-twitter">
                                                    <label for="skype"><?php _e('Skype', 'Cause'); ?></label>
                                                    <div class="inner-sec">
                                                        <input class="text-input" name="skype" type="text" id="skype" value="<?php the_author_meta( 'skype', $uid ); ?>" />
                                                    </div>
                                                  </li>
                                                </ul>
                                             </div>
                                             <div class="holder">   
                                               <div class="form-title">
                                                      <h4><?php _e('Social Media','Cause'); ?></h4>
                                                  </div>
                                                <ul class="upload-file">
                                                      <li class="form-facebook">
                                                          <label for="facebook"><?php _e('Facebook', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="facebook" type="text" id="facebook" value="<?php the_author_meta( 'facebook', $uid ); ?>" />
                                                          </div>
                                                      </li>
                                                      <li class="form-twitter">
                                                          <label for="twitter"><?php _e('Twitter', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="twitter" type="text" id="twitter" value="<?php the_author_meta( 'twitter', $uid ); ?>" />
                                                          </div>
                                                      </li>
                                                      <li class="form-lastfm">
                                                          <label for="lastfm"><?php _e('Linkedin', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="linkedin" type="text" id="linkedin" value="<?php the_author_meta( 'linkedin', $uid ); ?>" />
                                                          </div>
                                                      </li>
                                                      <li class="form-lastfm">
                                                          <label for="pinterest"><?php _e('Pinterest', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="pinterest" type="text" id="pinterest" value="<?php the_author_meta( 'pinterest', $uid ); ?>" />
                                                          </div>
                                                      </li>
                                                      <li class="form-lastfm">
                                                          <label for="lastfm"><?php _e('Google Plus', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="google_plus" type="text" id="google_plus" value="<?php the_author_meta( 'google_plus', $uid ); ?>" />
                                                          </div>
                                                      </li>
                                                      <li class="form-lastfm">
                                                          <label for="lastfm"><?php _e('Instagram', 'Cause'); ?></label>
                                                          <div class="inner-sec">
                                                              <input class="text-input" name="instagram" type="text" id="instagram" value="<?php the_author_meta( 'instagram', $uid ); ?>" />
                                                          </div>
                                                    </li>
                                                </ul>
                                             </div>
                                             <div class="holder">   
                                                  <div class="form-title">
                                                      <h4><?php _e('Password Update','Cause')?></h4>
                                                  </div>
                                                  <ul class="upload-file">
                                                    <li class="form-password">
                                                        <label for="pass1"><?php _e('New Password', 'Cause'); ?> </label>
                                                        <div class="inner-sec">
                                                          <input class="text-input" name="pass1" type="password" id="pass1" />
                                                        </div>
                                                    </li><!-- .form-password -->
                                                    <li class="form-password">
                                                        <label for="pass2"><?php _e('Repeat Password', 'Cause'); ?></label>
                                                        <div class="inner-sec">
                                                          <input class="text-input" name="pass2" type="password" id="pass2" />
                                                          <p>Enter same password in both fields. Use an uppercase letter and a number for stronger password.</p>
                                                          <?php //echo esc_attr($referer); ?>
                                                            <input name="updateuser" type="submit" id="updateuser" class="submit button cs-bg-color" value="<?php _e('Save', 'Cause'); ?>" />
                                                            <?php wp_nonce_field( 'update-user' ) ?>
                                                            <input name="action" type="hidden" id="action" value="update-user" />
                                                        </div>
                                                    </li><!-- .form-password -->
                                                  </ul>
                                             </div>
                                            </form><!-- #edituser -->
                                    </div>
                                    <?php } ?>
                              </div>
                               <?php
                                }
								elseif(isset($_GET['action']) && $_GET['action'] == 'favourites' && $current_user->ID == $uid){
                                  $width = 370;
                                  $height = 278;
								  cs_donation_count();	
                                ?>
                                <div class="cs-my-favorites">
                                	<div class="cs-section-title">
                                        <h2><?php _e('Favorites','Cause');?></h2>
                                    </div>
                                    <div class="cs-tabs nav_position_top">
                                    	<div class="tab-content">
                                            <div id="Viewall" class="tab-pane active">
                                            <?php 
                                                global $post, $cs_theme_options;
                                                $user = cs_get_user_id();
                                                if(isset($user) && $user <> ''){
                                                    $cs_wishlist = get_user_meta($user,'cs-cause-wishlist', true);
                                                    if(is_array($cs_wishlist) AND !empty($cs_wishlist)){
                                                        $cs_wishlist = array_filter( $cs_wishlist); 
                                                    } 
                                                }
                                                if(!empty($cs_wishlist) && count($cs_wishlist)>0){
                                                $args = array('post__in' => $cs_wishlist,'post_type'=> 'causes', 'order' => "ASC");
                                                    $custom_query = new WP_Query($args);
                                                    if( $custom_query->have_posts()){
                                                        while ( $custom_query->have_posts() ): $custom_query->the_post();	
                                                            ?>
                                                                <div class="holder alert alert-warning holder-<?php echo intval($post->ID); ?>">
                                                                    <figure><i class="fa fa-star"></i></figure>
                                                                    <section>
                                                                        <h5><a href="<?php the_permalink();?>"><?php the_title();?></a></h5>
                                                                        <ul class="post-option">
                                                                            <li><i class="fa fa-calendar"></i><time><?php echo date_i18n(get_option('date_format'), strtotime(get_the_date()));?></time></li>
                                                                        </ul>
                                                                    </section>
                                                                    <a onclick="javascript:cs_delete_wishlist('<?php echo esc_url(admin_url('admin-ajax.php'));?>','<?php echo intval($post->ID);?>')" class="close close-<?php echo intval($post->ID); ?>" href="#">×</a>
                                                                </div>
                                                     <?php
                                                        endwhile;
                                                       }else{
                                                               echo do_shortcode('[cs_message cs_message_style="btn_style" cs_message_icon="fa-lightbulb-o" cs_message_type="alert" cs_style_type="simp_info_messagebox" cs_message_close="no" cs_alert_style="threed_messagebox" ]'.__('No Favourite Causes(s).', 'Cause').'[/cs_message]');	
                                                        }
                                                        wp_reset_query();
                                                }else{
                                                    echo do_shortcode('[cs_message cs_message_style="btn_style" cs_message_icon="fa-lightbulb-o" cs_message_type="alert" cs_style_type="simp_info_messagebox" cs_message_close="no" cs_alert_style="threed_messagebox" ]'.__('No Favourite Causes(s).', 'Cause').'[/cs_message]');	
                                                }
                                                ?>
                                             </div>
                                    	</div>
                                    </div>
                                </div>	
                                <?php
                            	} 
								?>      
                        </div>
                   </div>
                </div>
                 <?php } ?>
            </div>
        </div>
    </section>            
<?php  get_footer(); ?>